import compileall

compileall.compile_dir('compil')