#!/bin/sh

# Compile the templates
./cheetah.py compile default/*.tmpl

# Move them into the action directory
mv default/*.py ../do/tmpl/default/
