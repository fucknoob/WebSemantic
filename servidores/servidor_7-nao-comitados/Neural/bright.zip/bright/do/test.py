"""Some very simple mod_python tests.

These use little of the framework and no Cheetah templates.
See test2.py for more advanced tests.
"""


from bright.ManagerObj import *


def text(req, name="there"):
	"""Return some text, adding in name if provided
	
	Call with:
	/do/test.py/text
	/do/test.py/text?name=Eric
	"""
	return "Hello %s" % _helper(name)
	
	
	
def list(req, caps=0):
	"""Return a list of people, uppercasing them if required
	
	Call with:
	/do/test.py/list
	/do/test.py/list?caps=1
	"""
	
	people = ['Andy','Eric','Steve']
	html = "<html><body>"
	for p in people:
		if caps:
			html += "%s<br/>" % p.upper()
		else:
			html += "%s<br/>" % p
	html += "</body></html>"
	return html
	
	
	
def db(req):
	"""Return lists from database.
	
	See /resources/PRIVATE/bright.sql
	"""
	
	mgr = ManagerObj()
	mgr.sqlexecute( "SELECT * FROM List" )
	html = "<html><body>"
	for row in mgr.sqlresults():
		html += "<h1>%s: %s</h1><br/>%s<br/><br/>" % (row['code'], 
			row['name'], row['description'])
	mgr.finish()
	html += "</body></html>"
	return html
	

#----------------------------------------------------------
# HELPERS, THESE ARE PRIVATE BECAUSE THEY START WITH _
#----------------------------------------------------------

def _helper(name):
	return name.upper()
	
	