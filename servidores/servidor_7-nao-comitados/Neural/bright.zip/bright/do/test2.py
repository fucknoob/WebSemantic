"""Tests that use Cheetah and the framework.

See /tmpl/default directory for the templates.
"""


from bright.ManagerObj import *
from bright.Webapp2 import *
from busobj.ListMgr import *



def list(req):
	"""Fill template with list of people"""
	action = Action(req)
	action.load_prep_template( "test2_list.tmpl" )

	people = ['Andy','Eric','Steve']
	action.fill_template( "people", people )
	
	return action.finish()



def db1(req):
	"""Execute SQL and fill template with results.
	
	Results is a list of dictionaries (dicts) -- each dict
	maps column names to values
	"""
	
	action = Action(req)
	action.load_prep_template( "test2_db.tmpl" )

	mgr = ManagerObj()
	mgr.sqlexecute( "SELECT * FROM List" )

	action.fill_template( "rows", mgr.sqlresults().all() )
	
	mgr.finish()
	return action.finish()
	
	
	
def db2(req):
	"""Like db1 above, but use specialised manager object.
	
	No SQL here, that's contained in the manager object.

	Also, we use action to keep track of the manager
	object so that it's finished for us. Therefore no
	need to call mgr.finish(), and no chance of forgetting.
	"""
	
	action = Action(req)
	action.load_prep_template( "test2_db.tmpl" )
	mgr = action.register_manager( ListMgr() )
	
	action.fill_template( "rows", mgr.all_lists() )
	return action.finish()

