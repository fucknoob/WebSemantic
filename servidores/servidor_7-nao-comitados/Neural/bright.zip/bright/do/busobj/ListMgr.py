# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# Last modified: $Date: 2006/08/31 11:33:16 $
# Revision       $Revision: 1.5 $
# Revised by     $Author: eric $

# Major change history:


import MySQLdb
import os.path
import datetime

from bright.ManagerObj import *


class ListMgr(ManagerObj):
	"""Business Object for lists."""
	
	def __init__(self):
		ManagerObj.__init__(self)



	def all_lists(self):
		"""Return all lists from the database (as dicts)"""
		
		self.sqlexecute( """SELECT * FROM List""" )
		return self.sqlresults().all()
		

			
