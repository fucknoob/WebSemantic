# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-10 20:24:40 +0000 (Fri, 10 Nov 2006) $
# Revision       $Revision: 1044 $
# Revised by     $Author: ericclack $

# Major change history:


import inspect


class Debugger(object):
	"""A mix-in object that provides debugging features.
	
	log: log a message to apache log or stdout if not available
	debug: log calling function's args and local variables.
	dumpobj: log objects attributes and values"""
		
		
	def __init__(self):
		pass
		
		
	def log(self, message, tag=None, divider=False):
		"""Log a message either to apache error_log, or if not avaiable stdout
		
		tag and diveder can be used to make logged messages easier to find
		tag prefixes the message; divider, if true, causes a row of hyphens
		to be output."""
		
		if tag is None: tag = "LOG"
		message = "%s: %s" % (tag, message)
		
		try:
			from mod_python import apache
			if divider: apache.log_error( "-" * 60, apache.APLOG_NOTICE )
			apache.log_error( message, apache.APLOG_NOTICE )

		except ImportError:
			# We're not running inside mod_python, so simply print the logging to stderr
			#sys.stderr.write( "BusinessObj LOGGER: %s" % message )
			if divider: print "-" * 60
			print message

		except AttributeError:
			# We're not running inside mod_python, so simply print the logging to stderr
			#sys.stderr.write( "BusinessObj LOGGER: %s" % message )
			if divider: print "-" * 60
			print message



	def debug(self, message=None):
		"""Log debug info for caller including local variables"""
		
		caller = inspect.stack()[1]
		(frame, file, line, function) = caller[0:4]
		(arg_names, extra_args, extra_kwds, locals) = inspect.getargvalues( frame )
		formattedargs = inspect.formatargvalues(arg_names, extra_args, extra_kwds, locals)
		formattedlocals = ', '.join(["%s=%s" % (k, locals[k]) for k in locals.keys()])
	
		message = """\nFunction & Arguments: %s %s
Line %s of file %s
Locals: %s
""" % (function, formattedargs, line, file, formattedlocals)

		self.log(message)
		


	def dumpobj(self, obj):
		"""Dump attributes of object using self.log"""
		
		attribs = []
		for a in obj.__dict__:
			attribs.append( "%s=%s" % (a,obj.__dict__[a]) )
		self.log( "%s\nATTRIBUTES:\n%s" % (obj.__class__, '\n'.join(attribs)), "OBJECT" )
		
		