# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-10 20:24:40 +0000 (Fri, 10 Nov 2006) $
# Revision       $Revision: 1044 $
# Revised by     $Author: ericclack $

# Major change history:
# - added castbool


import re
import datetime


class SimpleTextMarkup(object):
	"""An object for translating simple text markup to HTML.
	
	line breaks signal <br>s TODO: two line breaks signal <p>s
	
	**bold** ::italics::
	$$small$$ ^^big^^
	
	""block quote""
	
	bullets:
	- like
	- this
	...for bulletted
	
	= like
	= this
	...for numbered
	
	headings:
	like this for h1
	===
	
	Or this for h2
	---

	Or this for h3
	...
	
	other stuff:
	TODO: [image a.gif]
	rule: ----
	CSS styles: [style] to the end of the text
	
	Links: emails have this automatically, as does anything starting http://
	- TODO: also, can change text of link like this: http://www.yahoo.com(Yahoo)
	- TODO: relative links? 
	
	restrictions
	- no tables
	- no nested lists"""
		
	def __init__(self):
		pass
		
		# To do...
		# mode params?
		# enable, disable features?
		
	
	def translate(self, text):
		
		if not text: return ""

		html = text
		
		# Order of these replacements is important! Don't change it
		
		# Strip out any HTML first
		# This would remove HTML: r = re.compile( r"</?[^>]+/?>" )
		# This escapes it:
		r = re.compile( r"<" )
		html = r.sub( "&lt;", html )
		r = re.compile( r">" )
		html = r.sub( "&gt;", html )
		
		# Line breaks
		r = re.compile( r"(\r\n|\n)" )
		html = r.sub( "<br/>\n", html )
		
		# Rules
		r = re.compile( r"\n[\-]{4,}" )
		html = r.sub( r"<hr/>", html )
				
		
		# Headings
		r = re.compile( r"(^|<br/>\n)([^<]+)<br/>\n[=]{3,}(<br/>|$)" )
		html = r.sub( r"\1<h1>\2</h1>", html )

		r = re.compile( r"(^|<br/>\n)([^<]+)<br/>\n[\-]{3,}(<br/>|$)" )
		html = r.sub( r"\1<h2>\2</h2>", html )
		
		r = re.compile( r"(^|<br/>\n)([^<]+)<br/>\n[\.]{3,}(<br/>|$)" )
		html = r.sub( r"\1<h3>\2</h3>", html )

				
		# List items -- bullets
		# First translate lines with a hyphen at the start into [li]s 
		# (later converted to <li>s)
		r = re.compile( r"^\-([^<]+)(<br/>)?$", re.MULTILINE)
		html = r.sub( r"[li]\1[/li]\n", html )
		
		# Now match sequences of [li]s with no <br>s and add <ol> around them
		r = re.compile( r"\[li\]([^<]+)\[/li\]" )
		html = r.sub( r"<ul>[li]\1[/li]</ul>", html )
		
		# Finally, convert [li]s to <li>s
		r = re.compile( r"\[(/?)li\]" )
		html = r.sub( r"<\1li>", html )


		# List items -- numbers
		# First translate lines with a hyphen at the start into [li]s 
		# (later converted to <li>s)
		r = re.compile( r"^\=([^<]+)(<br/>)?$", re.MULTILINE)
		html = r.sub( r"[li]\1[/li]\n", html )
		
		# Now match sequences of [li]s with no <br>s and add <ol> around them
		r = re.compile( r"\[li\]([^<]+)\[/li\]" )
		html = r.sub( r"<ol>[li]\1[/li]</ol>", html )
		
		# Finally, convert [li]s to <li>s
		r = re.compile( r"\[(/?)li\]" )
		html = r.sub( r"<\1li>", html )


		# Block quote
		r = re.compile( r'\"\"([^<]+?)\"\"', re.MULTILINE )
		html = r.sub( r"<blockquote>\1</blockquote>", html )

		# Bold
		r = re.compile( r"\*\*(.+)\*\*", re.MULTILINE + re.DOTALL )
		html = r.sub( r"<b>\1</b>", html )
		
		# Italics
		r = re.compile( r"::(.+)::", re.MULTILINE + re.DOTALL )
		html = r.sub( r"<em>\1</em>", html )
				
		# Small text
		r = re.compile( r"\$\$(.+)\$\$", re.MULTILINE + re.DOTALL )
		html = r.sub( r"<small>\1</small>", html )

		# Large text
		r = re.compile( r"\^\^(.+)\^\^", re.MULTILINE + re.DOTALL )
		html = r.sub( r"<big>\1</big>", html )

		# Styles
		r = re.compile( r"\[([^\]]+)\](.*)$", re.MULTILINE + re.DOTALL )
		html = r.sub( r"<span class='\1'>\2</span>", html )


		# Links, first match ones like this: http://www.yahoo.com(link to yahoo)
		# then links without brakets
		r = re.compile( r"(https?://)([^\s<>\(\)]+)\(([^\)]+)\)" )
		html = r.sub( r"<a href='\1\2'>\3</a>", html )
		
		# Ensure we don't replace previous links, by ensuring there's no quote
		# at the start
		r = re.compile( r"[^\'](https?://)([^\s<>]+)" )
		html = r.sub( r"<a href='\1\2'>\2</a>", html )

		# Email
		r = re.compile( r"([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)" )
		html = r.sub( r"<a href='mailto:\1@\2'>\1@\2</a>", html )


		return html
	


	def translate_list(self, list, keys):
		"""Translate strings in a list of hashes, dictated by keys.
		
		Original is copied to key_text"""
		
		newlist = list
		
		for i in newlist:
			for k in keys:
				i[k + "_text"] = i[k]
				i[k] = self.translate(i[k])
				
		return newlist
		
		
	
	
class Util(object):
	"""Class for general utility methods that should be accessible from anywhere
	   i.e. casting strings as ints"""
	   
	   
	def __init__(self):
		pass
		
		# To do...
		# mode params?
		# enable, disable features?
		
	
	
	
	def castfloat(self, default, *args):
		"""Cast all *args to floats, or default if not valid numbers"""
		
		floats = []
		for i in args:
			try:
				v = float(i)
			except TypeError:
				v = default
			except ValueError:
				v = default			
			floats.append(v)

		# Now either return a list, or return a single item if 
		# there's only one:
		if len(floats) == 1:
			return floats[0]
		else:
			return floats
	
	
	
	def castint(self, default, *args):
		"""Cast all *args to ints, or default if not valid numbers.
		
		Args can contain nested lists, in which case they are flattened."""
		
		# Catch case where a single arg is actually a list, and expand
		# accordingly
		params = []
		for a in args:
			if isinstance(a,list):
				params.extend(a)
			else:
				params.append(a)
		
		ints = []
		for i in params:
			try:
				# Remove any , if it's a string
				if isinstance(i, basestring): 
					i = i.replace(',','')
				v = int(i)
			except TypeError:
				v = default
			except ValueError:
				v = default			
			ints.append(v)

		# Now either return a list, or return a single item if 
		# there's only one:
		if len(ints) == 1:
			return ints[0]
		else:
			return ints



	def castbool(self, default, *args):
		"""Cast all *args to booleans, "0"=False too."""
		
		bools = []
		for b in args:
			try:
				if b == "0": v = False
				else: v = bool(b)
			except TypeError:
				v = default
			except ValueError:
				v = default			
			bools.append(v)

		# Now either return a list, or return a single item if 
		# there's only one:
		if len(bools) == 1:
			return bools[0]
		else:
			return bools
	
	
	
	def castdatetime(self, default, *args):
		"""Cast all *args to datetimes, or default if not valid datetimes
		
		Accepts datetimes in the following formats:
			10/1/2004
			10/1/2004 10:30
			10/12/2004 10:30:36
			10/1/04 10.30.33
		"""
		
		r = re.compile("(\d+)/(\d+)/(\d+)(\s+(\d+)[:\.]{1}(\d+)([:\.]{1}(\d+))?)?")

		dates = []
		for d in args:
			try:
				m = r.match( d )
				hour = minute = second = 0 # incase no time entered
				day = int(m.group(1))
				month = int(m.group(2))
				year = int(m.group(3))
				if m.group(5): hour = int(m.group(5))
				if m.group(6): minute = int(m.group(6))
				if m.group(8): second = int(m.group(8))
				# 2 digit year?
				if year < 100: 
					if year < 50: year += 2000
					else: year += 1900
				try:
					v = datetime.datetime( year, month, day, hour, minute, second ) 
				except ValueError:
					v = default
			except (TypeError,AttributeError):
				# Not valid format
				v = default
			dates.append(v)

		# Now either return a list, or return a single item if 
		# there's only one:
		if len(dates) == 1:
			return dates[0]
		else:
			return dates
