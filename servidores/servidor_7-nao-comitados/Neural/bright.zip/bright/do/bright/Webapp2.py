# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-17 10:54:45 +0000 (Fri, 17 Nov 2006) $
# Revision       $Revision: 1067 $
# Revised by     $Author: ericclack $

# Major change history:



import os
from Cheetah.Template import Template
import Cookie
import md5
import string
import re, datetime
import cPickle, urllib
import inspect

from mod_python import apache
from mod_python import util

from AppSettings import *
from User import *
from Debug import *
from Util import *



class Action(Debugger): #inherit from object if you don't need debugging
	"""Manage mod_python actions, cookies, security and templates.
	
	Action objects wrap mod_python request objects to offer easier
	management of web actions, including Cheetah processing, 
	extra form vars, redirects and cookies.

	This class works hand in hand with SecurityPolicy to implement
	cookie based security (using MD5 encryption).
	
	How to use:
	 1. Create an instance of a SecurityPolicy object, policy
	 2. Call class method Action.add_security_policy(policy)
	 3. Then proceed to use action instances as usual.
	 
	In secured actions, include these two lines:
		action = Action(req, unit)
		if not action.authorised(): return action.finish()"""
		
	# Security policies, which control login, logout and login_failed
	# methods below, plus define which urls can create action objects
	security_policies = [] # List of SecurityPolicy objects

	# Regexp for splitting modules and actions
	action_url_regexp = re.compile(r'/do/([^/]+)\.py/([^/\?]+).*')	
	
	# Name for global variables store
	globalUnit = "global"
	globalTimeout = AppSettings.global_timeout

	# Class for access violations
	class NotAuthorised(Exception): pass


	def __init__(self, req, unit="default"):
		# Call superclass
		Debugger.__init__(self)
		
		# Init
		self.req = req
		self.unit = unit

		self._namespace = []
		self._tmpl_dir = AppSettings.tmpl_root + unit
		self._tmpl_path = "/tmpl/" + unit
		self._tmpl_file = None
		self._tmpl_class = None
		
		self.vars = VariableStore( req, unit )
		self.globalVars = VariableStore( req, Action.globalUnit )

		self.fieldstorage = req.form
		self.redirectto = None
		
		# A list of managers registered with us, which we'll finish
		# in self.finish()
		self.managers = []
		
		# Template utilities, which might be replaced with a subclass
		# if this class is overridden
		self.util = ActionUtil()
		
		# These might be set below
		self.authorised_user = None 
		self.user_timed_out = None					
		
		# Get a logged in user if there is one
		# Sets user_timed_out appropriately
		user = self.load_user()
		
		# If this is a secured action check user is valid and authorised
		if self.my_policy():
			# Check for timeout first
			if self.user_timed_out:
				self.clear_user()
				self.redirect( self._append_forward_url(self.my_policy().timeout_expiry_page) )
				
			else:
				if not user:
					# No user signed on
					self.redirect( self._append_forward_url(self.my_policy().login_page) )				

				elif self.my_policy().roles and user.roleid not in self.my_policy().roles:
					# The signed on user doesn't have the right role
					self.redirect( self._append_forward_url(self.my_policy().not_permitted_page) )

				elif self.my_policy().areas and not (user.areas == User.Access_All_Areas or set(user.areas).intersection(self.my_policy().areas)):
					# The signed on user isn't permitted to access any of the required areas
					self.redirect( self._append_forward_url(self.my_policy().not_permitted_page) )

				else:
					# User is valid and authorised for the action
					self.authorised_user = user
	
		else:
			# Set the user (may be None)
			self.authorised_user = user					



	def _append_forward_url( self, url ):
		"""Add on cgi param forwardurl=... to url supplied"""
		
		# Append the page they were trying to load, so that it
		# can be saved in the login page
		forwardurlparam = "forwardurl=" + urllib.quote( self.req.unparsed_uri )
		
		# Do we need a ? or & to join our new param?
		if url.find("?") > 0: joiner = "&"
		else: joiner = "?"
		
		return url + joiner + forwardurlparam
		



	def register_manager( self, mgr ):
		"""Register this manager with this action so that we can finish it later"""
		
		self.managers.append( mgr )
		return mgr

		
	
	def load_prep_template(self, template):
		template = self.load_template_class(template)
		self.prepare_template(template)



	def load_template_class(self, template):
		"""Try to load the class for this template, otherwise just return tmpl.
		
		Compiled template classes massively increase performance, but they're
		a pain during development. This class together with the other
		treatment of templates below reasonably transparently manages
		the use of compiled or raw text templates."""

		# In production use the compiled class as it has better performance
		# Note that this is the class, not an instance, it will be instantiated later
		try:
			module_name = os.path.splitext(template)[0]
			exec "from tmpl.%s.%s import *" % (self.unit, module_name)
			exec "template = " + module_name
		except ImportError:
			# While developing, the raw template file is is easier to work with
			# but a bit slower in terms of performance
			# template is already file name, so nothing more to do 
			self.log( "Can't load template object %s" % template )
			
		return template
	
	
	
	def prepare_template(self, tmpl):
		"""Store template definition (either filename or Template class) for later output."""
		
		# Reset vals in case this function is called multiple
		# times with different templates (often the case in error handlers)
		self._tmpl_class = self._tmpl_file = None
		
		if not(isinstance(tmpl, basestring)) and issubclass(tmpl, Template):
			self._tmpl_class = tmpl
		else:
			# Otherwise assume it's a string
			self._tmpl_file = tmpl


	
	def fill_template(self, name, value):
		self._namespace.append( { name:value } )

		
		
	def fill_template_hash(self, hash):
		for k in hash.keys():
			if hash[k] is not None:
				self._namespace.append( { k:hash[k] } )


		
	def getformval(self, key, default=None):
		try: return self.fieldstorage[key]
		except KeyError: return default



	def getformvals(self, *args):
		list = []
		for k in args:
			list.append( self.getformval(k) )
		return list
		

	
	def redirect(self, url):
		"""Redirect the request to the given url, a client side redirect.
		
		The redirect must be the last header set, so we store it for output
		in the finish method, after any cookies.
		
		BECAUSE THE SECURITY ACTIONS MAY SET THIS IF NO AUTENTICATED
		USER, WE DON'T LET ANYONE ELSE SET IT IF ALREADY SET
		"""
																					
		if not self.redirectto: self.redirectto = url

	
	
	def finish(self):	
		"""Finish off the action by outputting the template, with HTTP header,
		providing the user has not issued a redirect."""
	
		# Any authorised user? If so, update the time of 
		# their last action and save them
		if self.is_user_signed_in(): 
			self.authorised_user.reset_timeout()
			self.save_user()

		# Any cookies set? If so, add the appropriate headers		
		self._output_cookies()
		
		# Redirect or process template?
		if self.redirectto:
			# Before returning, finish all of the managers
			for m in self.managers: m.finish()

			# Output redirect & don't output anything else 
			# (there shouldn't be anything to output anyway)
			self.req.headers_out['Location'] = self.redirectto
			self.req.status = apache.HTTP_MOVED_TEMPORARILY
			return self.redirectto
		else:
			# Set base tag filling
			self.fill_template("base", self.generate_base_tag())
			
			# Add in user
			if self.is_user_signed_in():
				self.fill_template('user', self.user)
			else:
				self.fill_template('user', None)

			# Add in util object
			self.fill_template( "util", self.util )
			
			# We've either got a template class passed in (previously
			# compiled with cheetah compile) or a filename of a template
			if self._tmpl_class:
				t = self._tmpl_class( searchList = self._namespace )
				# Set this for includes
				t._fileDirName = self._tmpl_dir
			else:
				t = Template(file = self._tmpl_dir + "/" + self._tmpl_file, searchList = self._namespace )
				
			# This call might use a manager, so call it before
			# finishing with them
			html = str(t)
			
			# Before returning, finish all of the managers
			for m in self.managers: m.finish()
			return html



	def generate_base_tag(self):
		# Just check that we're running in a web server...
		if os.environ.get("HTTP_HOST"):
			base = "http://"
			base += os.environ.get("HTTP_HOST")
			if int(os.environ.get("SERVER_PORT")) != 80:
				base += ":" + os.environ.get("SERVER_PORT")
			base += self._tmpl_path + "/" + self._tmpl_file		
		else:
			base = '#'
		return base
		
		
		
	def forwardfields(self, hash):
		"""Generate and fill template with HTML hidden fields for a set of variables.
		
		So that they can be passed on to next action. This is nice and
		extendible (from the code) without having to keep editing HTML."""
		
		html = ""
		for name in hash.keys():
			html += '<input type="hidden" name="%s" value="%s">\n' % (name, hash[name])
	
		self.fill_template("forwardfields", html)
		
		
	#-------------------------------------------------------------------
	# STATIC UTILITY METHODS
	#-------------------------------------------------------------------

		
	def makesafe(s):
		"""Strip out forbidden chars so that s is safe to make paths from."""
		if s:
			return s.translate( 
				string.maketrans(AppSettings.trans_chars,'_' * len(AppSettings.trans_chars)), 
				AppSettings.forbidden_chars )
		else:
			return None
	makesafe = staticmethod(makesafe)

		
	def castint(default, *args):
		"""Cast all *args to ints, or default if not valid numbers"""
		
		util = Util()
		return util.castint(default, *args)
	castint = staticmethod(castint)



	def castbool(default, *args):
		"""Cast all *args to boolean, or default if not valid"""
		
		util = Util()
		return util.castbool(default, *args)
	castbool = staticmethod(castbool)
		


	def castdatetime(default, *args):
		"""Cast all *args to datetimes, or default if not valid datetimes
		
		  **updated to make use of the util castdate method - enables non action classes to make
		  use of the casting functionality...
		"""
		
		util = Util()
		return util.castdatetime(default, *args)
	castdatetime = staticmethod(castdatetime)



	def make_html_options(list, selected):
		"""Make a set of options for a drop down list.
		
		List is a list of (value, label) - eg [ (1, 'Jan'), (2, 'Feb'), ... ]
		
		As a rule it's bad practice to put HTML in code, but here it's
		OK since we wont be changing any styles or presentation. """
		
		def _selected(value, selected):
			"""Return selected part of option if appropriate."""
			selected_string = ""
			if ( value == selected ): selected_string = "selected='true'"
			return selected_string

		option_list = [ "<option value='%s' %s>%s</option>" % (value, _selected(value, selected), label) for (value, label) in list ]
		return '\r'.join(option_list)
	make_html_options = staticmethod(make_html_options)



	def escape_html(dict):
		"""Escape any ", <, > or & signs in the dict values
		
		Keep original, in html form, in key_html"""
		
		for key in dict.keys():
			v = dict[key]
			if isinstance(v, basestring):
				v = v.replace('&','&amp;').replace('"','&quot;').replace('<','&lt;').replace('>','&gt;')
				dict[key+"_html"] = dict[key]
				dict[key] = v
		return dict	
	escape_html = staticmethod(escape_html)



	#-------------------------------------------------------------------
	# SECURITY METHODS
	#-------------------------------------------------------------------


	def login(self, user):
		# Add timeout period to user
		if self.my_policy():
			user.timeout = self.my_policy(check_actions=False).timeout
		else:
			user.timeout = Action.globalTimeout
			
		self.authorised_user = user
		self.user_timed_out = False
		# No need to save here, as finish() does it
		
		

	def save_user(self):
		"""Save the authorised user to a cookie, ready for the next action.
		
		The user cookie is stored in global variable store so it can be accessed
		by any module."""
		
		pickled_user = cPickle.dumps( self.authorised_user, 1 )
		self.globalVars.save_secure( "user", urllib.quote(pickled_user) )



	def load_user(self):
		"""Load the user from the secure cookie or return None.
		
		Once loaded we check they have not gone away."""
		try:
			pickled_user = urllib.unquote(self.globalVars.load_secure( "user" ))
		except:
			# Any error and we give up!
			pickled_user = None

		user = None
		if pickled_user: 
			user = cPickle.loads( pickled_user )
			
			# Check if user has gone away
			if user.has_timed_out():
				user = None
				self.user_timed_out = True
			else:
				self.user_timed_out = False

		return user

				

	def authorised(self):
		"""Do we have an authorised user? Return True/False"""
		
		# First check that a policy applies to this action
		# otherwise errors (e.g. missing polices) are hard
		# to debug
		assert self.my_policy(), "No policy applicable to this action. Check SecurityPolicy.module and SecurityPolicy.actions"
		return (self.authorised_user and not self.user_timed_out)
	
	
	def is_user_signed_in(self):
		"""Is there a user signed in? 
		
		Same as authorised (above) but doesn't insist on a policy
		being applicable to this action."""
		return (self.authorised_user and not self.user_timed_out)

	

	def user(self):
		"""Return authorised user (loaded in constructor) or throw exception"""

		if not self.authorised_user: raise Action.NotAuthorised
		if self.user_timed_out: raise Action.NotAuthorised

		return self.authorised_user



	def clear_user(self):
		"""Remove the user from action and cookie.
		
		Does not affect action flow."""		
		self.globalVars.save_secure( "user", "" )		
		self.authorised_user = None
		


	def logout(self):
		"""Logout this user, clear the cookie and redirect to post logout page."""
		self.clear_user()
		self.redirect( self.my_policy(check_actions=False).post_logout_page )
	

	
	def login_failed(self, forwardurl=None):
		"""A login attempt failed, clear any cookie and redirect to the login page.
		
		Assumes there is a security policy."""		
		
		self.clear_user()
		if forwardurl: 
			forwardurl = "&forwardurl=%s" % urllib.quote( forwardurl )
		else:
			forwardurl = ""
		self.redirect( self.my_policy(check_actions=False).failed_login_page + forwardurl )
		
		
	
	def my_policy(self, check_actions=True):
		"""Return the policy relevant to this action instance, if any.
		
		Use check_actions=False if you don't care about the current
		action but do care about the current module. Very useful for
		login which cannot be a secured action."""
		
		#self.log( Action.security_policies )
		if not Action.security_policies: return None

		(my_module, my_action) = self.module_and_action()
		for p in Action.security_policies:
			if not check_actions and p.secured_module(my_module):
				return p
			if p.secured_action(my_module, my_action):
				return p
		
		self.log( 'None found!' )
		return None

	
	#-------------------------------------------------------------------
	# CLASS METHODS
	#-------------------------------------------------------------------
	
	def add_security_policy(cls, policy):
		"""Add this policy to the list defined for all action instances."""
		cls.security_policies.append(policy)
	add_security_policy = classmethod(add_security_policy)
		

	#-------------------------------------------------------------------
	# HELPERS
	#-------------------------------------------------------------------


	def module_and_action(self):

		# Use class regexp to split url
		matches = Action.action_url_regexp.match(self.req.uri)
		module = action = None
		
		if matches:
			try:
				module = matches.group(1)
				action = matches.group(2)
			except IndexError:
				# No match, nothing to do
				pass
			
		return (module, action)


	#-------------------------------------------------------------------
	# PRIVATE HELPERS
	#-------------------------------------------------------------------


	def _output_cookies(self):
		"""Output headers for the module and global Variable stores."""
		
		if self.vars.cookieChanged:
			self._set_cookie_vars(self.vars)

		if self.globalVars.cookieChanged:
			self._set_cookie_vars(self.globalVars)



	def _set_cookie_vars(self, vars):
		"""Output a string for the given variable store."""
		
		for name in vars.cookies_out.keys():
			cookie_string = vars.cookies_out[name].OutputString()
			
			if self.redirectto:
				# If we're about to do a redirect, then we need to append
				# to the error headers, not the normal headers
				self.req.err_headers_out.add( "Set-Cookie", cookie_string )
			else:			
				self.req.headers_out.add( "Set-Cookie", cookie_string )

		


class VariableStore(object):
	"""A wrapper around the Cookie.SimpleCookie adding security and convenience.
	
	This object is aggregated inside the Action object for storing
	and later outputting cookies. The secured methods
	use an MD5 key to ensure that the variables cannot be tampered with."""

	def __init__(self, req, unit="default"):
		self.unit = unit
		try: 
			self.cookies_in = Cookie.SimpleCookie( req.headers_in['Cookie'] )
		except KeyError: 
			self.cookies_in = Cookie.SimpleCookie()

		self.cookies_out = Cookie.SimpleCookie()
		self.cookieChanged = 0
		self._md5secret = AppSettings.md5_secret



	def load(self, id, secure=False, unit=None):
		"""Load a variable and if secure then check its hash key is correct."""
		
		if unit is None: unit = self.unit
		name = unit+"_"+id
		try: val = self.cookies_in[name].value
		except KeyError:
			# No cookie set, so just return None
			return None					

		if secure:
			try: key = self.cookies_in[name + '_key'].value
			except KeyError: raise AssertionError, "No secure key"
			
			m = md5.new()
			m.update(self._md5secret)
			m.update(id)
			m.update(val)
			if m.hexdigest() != key:
				raise AssertionError, "Keys don't match"
		
		return val

	# Shortcuts for the above load method
	
	def load_secure(self, id, unit=None): return self.load(id, secure=True, unit=unit)

	def loadint(self, id, secure=False, unit=None): 
		v = self.load(id, secure, unit)
		try: v = int(v)
		except: v = None
		return v


	def save(self, id, val, secure=False, expires=None, unit=None):
		"""Save a variable together with a hash key for security if required.
						
		Expires if specified is the number of minutes in which the cookie
		should expire. If None, this is a session cookie and will expire once
		the browser window is closed."""
		
		if unit is None: unit = self.unit
		
		self.cookieChanged = 1
		name = unit+"_"+id
		self.cookies_out[name] = val
		self.cookies_out[name]['path'] = '/'
		
		if expires is not None:
			expiry_time = datetime.datetime.now() + datetime.timedelta( minutes=expires )
			expiry_string = expiry_time.strftime("%a, %d-%b-%Y %H:%M:%S GMT")
			self.cookies_out[name]['expires'] = expiry_string
		
		if secure:
			m = md5.new()
			m.update(self._md5secret)
			m.update(id)
			m.update(str(val))
			self.cookies_out[name + '_key'] = m.hexdigest()
			self.cookies_out[name + '_key']['path'] = '/'
			if expires is not None:
				self.cookies_out[name + '_key']['expires'] = expiry_string

	def save_secure(self, id, val, expires=None):
		self.save(id, val, secure=True, expires=expires)
	
	
	
	def persist(self, id, val, secure=False, expires=None):
		"""If id has a value, save it, otherwise try to load it"""
		
		if val: 
			self.save(id, val, secure, expires)
		elif self.load(id): 
			val = self.load(id, secure)

		return val

	def persist_secure(self, id, val, expires=None):
		return self.persist(self, id, val, secure=True, expires=expires)
		
		
		

class ActionUtil(object):
	"""A utility class which contains methods to make templating easier.
	
	An instance of this class is passed to templates as 'util' and
	the templates can then use calls such as util.format_date($date)
	to output nice dates, or util.html_select(...) to generate
	a drop down list from a list of items.
	
	Methods that take a list work with lists of dicts or objects.
	"""
	

	def __init__(self):
		pass
		

	def format_edit_date(self, date):
		try: return date.strftime(AppSettings.format_edit_date)
		except AttributeError: return ""

		
	def format_date(self, date):
		try: return date.strftime(AppSettings.format_show_date)
		except AttributeError: return ""

		
	def format_thousands(self, val, decimal_places=0):
		def _addseps(s):
			p=s.find('.')
			if p==-1: p=len(s)
			for i in range(p-3,s[0] in ('+','-'),-3): s=s[:i]+','+s[i:]
			return s
		format = "%%.%sf" % decimal_places
		if val or val == 0: return _addseps(format % val)	
		
	
	def escape_html(self, field):
		try:
			return field.replace('&','&amp;').replace('"','&quot;').replace('<','&lt;').replace('>','&gt;')
		except AttributeError:
			return ""
		
	
	def escape_cgi(self, text):
		try: return urllib.quote(text)
		except TypeError: return ""


	def plain_text(self, text, remove_entities=False):
		"""Convert XML or HTML to plain text, removing tags and converting &
		
		Useful for summaries of HTML or using text in XML"""
		
		# Return nothing for blanks
		if not text: return text
		
		# Remove any entities?
		if remove_entities:
			regexp = re.compile(r"&\w+?;") # &name;
			text = regexp.sub('',text)
		
		# Encode & signs
		text = text.replace('&','&amp;')
	
		# Remove tags 
		regexp = re.compile(r"</?[^>]+>") # any tag including close tags
		text = regexp.sub(' ',text)
		
		return text
		

	def simple_text_markup(self, text):
		stm = SimpleTextMarkup()
		return stm.translate(text)
		
		
	def html_select(self, name, items, idfield, valuefield, 
		selectedid=None, initial_null="", attributes=None):
		"""Return a <select> element with <option>s for each item.
		
		Works with lists of dicts or objects.
		selectedid, if specified, determines which one is selected.
		initial_null, if specified, creates an initial prompt, 
		e.g. "[None selected]"
		attributes is a string of attributes to insert into the select tag"""
		
		options = []
		if initial_null:
			options.append("""<option value="">%s</option>""" % initial_null)
			
		for i in items:
			# Do we have a dict or an object? Make sure we
			# have a dict for the methods below
			if isinstance(i,dict): d=i
			else: d=i.__dict__

			if selectedid == d[idfield]:
				selectedflag = 'selected="selected"'
			else:
				selectedflag = ""
			options.append("""<option value="%s" %s>%s</option>""" % (d[idfield], selectedflag, d[valuefield]) )
		return """<select name="%s" id="%s" %s>%s</select>""" % (name, name, attributes, ''.join(options))
		
		
	def html_checkboxes(self, name, items, idfield, valuefield, 
		selectedids=None, classname="checkbox", separator='<br/>'):
		"""Return <input> checkboxes for each item in list.
		
		Works with lists of dicts or objects.
		selectedids is a list (or single value) that specifies which 
		ones should be checked."""
		
		# Make sure selectedids is a list
		if not isinstance(selectedids, list): 
			selectedids = [selectedids]
		
		# Now generate html for each checkbox
		checkboxes = []
		for i in items:
			# Do we have a dict or an object? Make sure we
			# have a dict for the methods below
			if isinstance(i,dict): d=i
			else: d=i.__dict__
			
			if d[idfield] in selectedids:
				selectedflag = 'checked="checked"'
			else:
				selectedflag = ""			

			checkboxid = "_".join( (name, `d[idfield]`) )
			checkboxes.append("""<input type="checkbox" name="%s" value="%s" id="%s" class="%s" %s /><label for="%s">%s</label>""" % (name, d[idfield], checkboxid, classname, selectedflag, checkboxid, d[valuefield]) )
		return separator.join(checkboxes)
		

	def app_setting(self, setting):
		return AppSettings.__dict__[setting]


	def text_abbreviate(self, text, max_len, dotsplacement=1.0):
		"""If text is longer than max_len, abbreviate it.
		
		dotsplacement (a float) determines where to put dots
		= 0 put it at start
		= 1 put it at end
		a float between 0 and 1, place it inside the string.
		
		The last option is useful for these sorts of strings:
		/usr/local/my...end-of-a-really-long-path.txt
		"""
		
		if not text: return text
		if len(text) > max_len:
			split1 = int(dotsplacement*max_len)
			split2 = max_len - split1
			abtext = text[:split1] + "..."
			if split2:
				abtext += text[-split2:]
		else:
			abtext = text
		return abtext
		
		
