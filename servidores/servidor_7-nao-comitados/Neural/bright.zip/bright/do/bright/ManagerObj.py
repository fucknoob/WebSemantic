# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-17 10:54:45 +0000 (Fri, 17 Nov 2006) $
# Revision       $Revision: 1067 $
# Revised by     $Author: ericclack $

# Major change history:


import MySQLdb
import re
from AppSettings import *
from BusinessObj import *


class ManagerObj(BusinessObj):
	"""Base class for Manager Objects, with a connection to a database.
	
	If you don't need a connection to the database, consider using
	BusinessObj instead. 
	
	This object maintains a connection to the database which you MUST
	release by calling finish() when you're done with the object."""
	

	def __init__(self):
		"""Create a short-lived connection for this business object
		should be closed when this object goes out of scope
		We can do this with MySQL because of the minimal connection overhead"""
		
		self.db = MySQLdb.connect( AppSettings.db_host, AppSettings.db_user, AppSettings.db_password, AppSettings.db_name )
		self.cursor = self.db.cursor()
		
		# Debugging? This will log all SQL statements to apache log
		self.debug = AppSettings.db_debug


	def finish(self):
		"""Finish up, release resources, e.g. database connections."""
		self.db.close()

	
	def sqlexecute(self, sql, params=None):
		"""Execute the SQL statement with any params passed."""
		
		# Write out the SQL statement for debugging?
		if self.debug:
			try:
				if params:
					self.log( sql % params )
				else:
					self.log( sql )
			except TypeError: 
				# well, we tried
				self.log( 'SQL: %s' % sql )
				self.log( 'PARAMS: %s' % params )
				
		self.cursor.execute(sql, params)
		return self
		
		
	def sqlfetchfirst(self):
		"""Fetch the first column of the first row of the sqlresults."""
		row = self.cursor.fetchone()
		if not(row): return None
		return row[0]
		
		
	def sqlfetchblob(self):
		"""Fetch the first BLOB column of the first row of the sqlresults.
		
		For some reason we get back an array, with the BLOB in the 2nd position.
		So this method retrieves that for the caller"""
		row = self.cursor.fetchone()
		return row[0][1]


	def sqlfetchhash(self):
		"""Return a row of the database with the column names as keys.
		
		Note: Column names are lowercased."""
		row = self.cursor.fetchone()
		if not(row): return None
		
		hash = {}
		count = 0
		for d in self.cursor.description:
			hash[ d[0].lower() ] = row[count]
			count = count + 1
		
		return hash
	

	def sqlresults(self):
		return NamedSQLIterator(self)
		

	def sqllastinsertid(self):
		"""return the last id inserted on the current connection"""
		sql = "SELECT LAST_INSERT_ID() AS id"
		self.sqlexecute(sql)

		return self.sqlfetchfirst()


	def sqldate2uk(self, sqldate):
		"""Convert a date of the form yyyy-mm-dd to dd/mm/yyyy
		
		If there's a time, copy this across unchanged."""
		
		# Convert to a string
		sqldate = str(sqldate)
		time = ""
		try: 
			(date, time) = sqldate.split(' ')
			sqldate = date
			time = " " + time
		except ValueError: pass
		
		try:
			f = sqldate.split('-')
			return "%s/%s/%s%s" % (f[2], f[1], f[0], time)
		except IndexError: return None
		
		
	def ukdate2sql(self, ukdate):
		"""Convert a date of the form dd/mm/yyyy to yyyy-mm-dd
		
		If there's a time, copy this across unchanged."""
		
		ukdate = str(ukdate)

		# It might actually be in the right format?
		regexp = re.compile(r"\d\d\d\d-\d\d-\d\d")
		if regexp.match(ukdate):
			return ukdate
			
		time = ""
		try: 
			(date, time) = ukdate.split(' ')
			ukdate = date
			time = " " + time
		except ValueError: pass
		
		f = ukdate.split('/')
		try: return "%s-%s-%s%s" % (f[2], f[1], f[0], time)
		except IndexError: return None
		
		
	def format_currency(self, val):
		# For some reason the simple locale functions
		# don't work here -- perhaps a Mac problem?
		if val or val == 0: return self._addseps("%.2f" % val)
		
		
	def format_row(self, row, date_cols, currency_cols=[]):
		"""Format many items of row at once, depending on the cols specified"""
		
		if date_cols:		
			for c in date_cols:
				row[c] = self.sqldate2uk(row[c])
				
		if currency_cols:	
			for c in currency_cols:
				row[c] = self.format_currency(row[c])
		
	
	def trunc_fields(self, row, fields, length, inplace="1"):
		"""Truncate fields and remove any tags
		
		length:		the number of characters to truncate at
		inplace:	whether the truncation should replace
					the original item in row, if not, then a new item
					short_original-name is created."""
		
		for r in fields:

			# Skip blank fields
			if not (r in row and row[r]): continue
			
			# First remove tags so that when we truncate we
			# don't break html
			regexp = re.compile(r"</?[^>]+>") # any tag including close tags
			trunc = regexp.sub(' ',row[r])
			
			try:
				if len(trunc) > length:
					trunc = trunc[0:length]
					trunc += '...'
				if inplace:
					row[r] = trunc
				else:
					row['short_' + r] = trunc
			except: pass
			
	

	# HELPERS ..............................................
	
	def _addseps(self, s):
		p=s.find('.')
		if p==-1: p=len(s)
		for i in range(p-3,s[0] in ('+','-'),-3):
			s=s[:i]+','+s[i:]
		return s
		


class NamedSQLIterator(object):

	def __init__(self, busobj):
		self.busobj = busobj # Creator
		
		
	def __iter__(self):
		return self
		

	def next(self):
		hash = self.busobj.sqlfetchhash()
		if hash:
			return hash
		else:
			raise StopIteration
		

	def all(self, idcol=None, idval=None, seltag=None, notseltag=None):
		rows = []
		for row in self:
			if idcol and idval and row[idcol] == idval:
				row[seltag] = seltag
			elif not(notseltag is None):
				row[seltag] = notseltag
			rows.append(row)
		return rows
		


class SQLCriteria(object):
	"""Manage SQL Where clauses for variable params, e.g. from a web form"""

	def __init__(self):
		self.clauses = []
		self.params = []


	def add(self, where, param):
		"""Add a simple where clause of the form WHERE where=param"""
		self.clauses.append(where)
		self.params.append(param)		
		
		
	def add_list(self, where_field, params):
		"""Like .add but can cope with lists of params and IN clauses"""
		# Is params a single item or a list?
		if isinstance(params,list):
			# Generate one place holder for each param
			placeholders = "%s," * len(params)
			placeholders = placeholders[:-1] # remove final ,
			placeholders = "(%s)" % placeholders
			# Now create clause			
			self.clauses.append(where_field + " IN " + placeholders )
			self.params.extend(params)
		else:
			self.clauses.append(where_field + "=%s")
			self.params.append(params)		


	def add_exists(self, subselect, params):
		"""Like .add_list but wraps EXISTS clause for Many-to-Many mappings"""
		self.add_list(subselect, params)
		# Wrap new item with EXISTS ( )
		self.clauses[-1] = "EXISTS ( %s )" % self.clauses[-1]
		

	def where_clause(self, boolean_operator="AND", include_where=True):
		"""Output appropriate where clause with boolean_operator between them"""
		if self.clauses:
			boolean_operator = " %s " % boolean_operator
			sql = boolean_operator.join(self.clauses)
			if include_where: sql = " WHERE " + sql
			return sql
		else:
			return ""
			