# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-10 20:24:40 +0000 (Fri, 10 Nov 2006) $
# Revision       $Revision: 1044 $
# Revised by     $Author: ericclack $

# Major change history:
#	5Jul06	Eric	Added meta1,2,3 attributes



import random
from bright.ManagerObj import *
from bright.User import *



class UserMgr(ManagerObj):
	"""Manage users, including sign on.
	
	Almost all of these methods assume that the user has been
	signed on, i.e. that passed user objects have been
	correctly obtained. IT'S THE CALLER's RESPONSIBILITY
	TO ENSURE THIS!
	
	Note that the password for the user never leaves this 
	manager object and so cannot be displayed to users
	or others.
	
	This object assumes a table called User with schema:

CREATE TABLE `ListUser` (
  `userid` int(11) NOT NULL auto_increment,
  `u_roleid` int(11) default NULL,
  `u_username` varchar(50) default NULL,
  `u_password` varchar(50) default NULL,
  `u_email` varchar(50) default NULL,
  `u_name` varchar(50) default NULL,
  `u_org` varchar(50) default NULL,
  `u_position` varchar(50) default NULL,
  `u_linkid` int(11) default NULL,
  `u_meta1` varchar(50) default NULL,
  `u_meta2` varchar(50) default NULL,
  `u_meta3` varchar(50) default NULL,
  PRIMARY KEY  (`userid`),
  UNIQUE KEY `u_username` (`u_username`),
  KEY `u_email` (`u_email`)
) 

	And optionally two further tables (if Check_Secured_Areas=True)

CREATE TABLE `AreaRoleRights` (
  `AreaRoleRightsID` int(11) NOT NULL auto_increment,
  `ARR_RoleID` int(11) default NULL,
  `ARR_AreaID` int(11) default NULL,
  `ARR_Level` int(11) default NULL,
  PRIMARY KEY  (`AreaRoleRightsID`)
)

CREATE TABLE `securearea` (
  `SecureAreaID` int(11) NOT NULL auto_increment,
  `SA_Name` varchar(255) default NULL,
  `SA_Description` varchar(255) default NULL,
  PRIMARY KEY  (`SecureAreaID`)
)
"""
	
	# Should we check areas and store this info with user?
	Check_Secured_Areas = False
	
	
	def __init__(self):
		
		# Call superclass to get connection to database
		# Don't forget to call finish later!
		ManagerObj.__init__(self)
		
		# Caches
		self._role_areas_cache = {}


	def signon(self, username, password, role=None):
		"""Signon the user then create a user object for them."""
		
		if role is None: dontcheckrole = 1
		else: dontcheckrole = 0
		sql = """SELECT * FROM ListUser
							WHERE U_Username = %s AND U_Password = %s
								AND (%s=1 OR U_RoleID = %s)"""
		self.sqlexecute( sql, (username, password, dontcheckrole, role) )
		user = self.sqlfetchhash()
		self.log( user, tag="USER>>>>")

		userobj = None
		if user: 
			# There was a user, they have provided the right credentials
			userobj = self._populate_user_from_record( user )
		return userobj



	def get_user_from_linkid(self, linkid, roleid):
		"""Get a user from their linkid & roleid, WITHOUT CHECKING PASSWORD."""
		
		sql = """SELECT * FROM ListUser
							WHERE U_LinkID = %s
							AND U_RoleID = %s"""
						
		self.sqlexecute( sql, (linkid, roleid) )
		user = self.sqlfetchhash()
		userobj = self._populate_user_from_record( user )
		
		return userobj



	def get_user_by_email(self, email, role=None ):
		"""Return user given email address, or None if there is no match."""
		
		sql = "SELECT * FROM ListUser WHERE U_Email = %s"
		params = [email]
		if role:
			sql += " AND U_RoleID = %s "
			params.append(role)
		
		self.sqlexecute( sql, params )
		user = self.sqlfetchhash()		
		userobj = self._populate_user_from_record( user )
		
		return userobj



	def get_user_by_id(self, id):
		"""Return user given id, or None if there is no match."""
		
		sql = "SELECT * FROM ListUser WHERE UserID = %s"		
		self.sqlexecute( sql, id )
		user = self.sqlfetchhash()		
		userobj = self._populate_user_from_record( user )
		
		return userobj



	def get_user_by_username(self, username):
		"""Return user given username, or None if there is no match."""
		
		sql = """SELECT * FROM ListUser WHERE U_Username = %s"""
		
		self.sqlexecute( sql, username )
		user = self.sqlfetchhash()		
		userobj = self._populate_user_from_record( user )
		
		return userobj
	


	def add_user(self, userobj):
		"""Add a user object to the database."""
		
		sql = """INSERT INTO ListUser 
							(u_roleid, u_username, 
							 u_email, u_name, u_linkid,
							 u_org, u_position,
							 u_meta1, u_meta2, u_meta3)
							VALUES
								(%s,%s, %s,%s,%s, %s,%s, %s,%s,%s)"""
						
		self.sqlexecute( sql, (userobj.roleid, userobj.username,
			userobj.email, userobj.name, userobj.linkid,
			userobj.org, userobj.position,
			userobj.meta1, userobj.meta2, userobj.meta3))		

		userobj.internalid = self.sqllastinsertid()



	def save_user(self, userobj):
		"""Save (update) a user object in the database."""
		
		sql = """UPDATE ListUser 
							SET u_username=%s, 
							 u_email=%s, u_name=%s, u_linkid=%s,
							 u_org=%s, u_position=%s, u_roleid=%s,
							 u_meta1=%s, u_meta2=%s, u_meta3=%s
						WHERE userid = %s"""
						
		self.sqlexecute( sql, (userobj.username,
			userobj.email, userobj.name, userobj.linkid,
			userobj.org, userobj.position, userobj.roleid,
			userobj.meta1, userobj.meta2, userobj.meta3,
			userobj.internalid))		


	
	def delete_user(self, id):
		"""Delete user given id"""
		
		sql = "DELETE FROM ListUser WHERE UserID = %s"
		self.sqlexecute( sql, id )



	def change_password(self, user, new_password):
		"""Change the password for the user supplied."""

		sql = """UPDATE ListUser SET U_Password = %s
							WHERE UserID = %s"""
		self.sqlexecute(sql, (new_password, user.internalid))
		


	def email_password(self, email, notifymgr, role=None):
		"""Email a password reminder to the user using notifymgr
		
		Returns true if a valid email address was found, false
		otherwise.
		Assumes that notifymgr has a method send_password_reminder()"""
		
		user = self.get_user_by_email(email, role)
		if not user:
			# No valid user found for this email
			return False

		password = self.__password_for_user(user)
		notifymgr.send_password_reminder( user.name, user.email, password, user.roleid )
		return True



	def welcome_new_user(self, user, notifymgr):
		"""Send a welcome message to the user using notifymgr
		
		Assumes that notifymgr has a method send_welcome()"""
		
		password = self.__password_for_user(user)		
		notifymgr.send_welcome( user.name, user.email, user.username, password, user.roleid )



	#-------------------------------------------------------------------
	# HELPERS
	#-------------------------------------------------------------------
	

	def gen_random_password(name):
		"""Generate a random password using the name as a seed."""
		
		# Remove spaces, tabs and other punctuation from name
		r = re.compile('[^\w\d]*')
		name = r.sub('',name)
		
		alpha = "abcdefghijklmnopqrstuvwxyz"
		seed = name + alpha
		p1 = list(seed)
		random.shuffle(p1)

		# Now shorten to a reasonable length
		p2 = p1[:10]
		random.shuffle(p2)
		return ''.join(p2)
		
	gen_random_password = staticmethod(gen_random_password)

		

	#-------------------------------------------------------------------
	# PRIVATE HELPERS
	#-------------------------------------------------------------------			


	def _populate_user_from_record(self, user):
		userobj = None
		if user: 
			areas = self._role_areas(user['u_roleid'])
			userobj = User(user['userid'], user['u_username'], 
					user['u_name'], user['u_email'], user['u_roleid'], 
					user['u_org'], user['u_position'], user['u_linkid'],
					user['u_meta1'], user['u_meta2'], user['u_meta3'],
					areas)
		
		return userobj	
		
		

	def __password_for_user(self, user):
		"""Lookup password for this user."""
		
		sql = """SELECT * FROM ListUser
							WHERE UserID = %s"""
		self.sqlexecute( sql, user.internalid )
		user = self.sqlfetchhash()
		return user['u_password']



	def _role_areas(self, roleid):
		"""Which areas do users of this role have access to?
		
		This is often called within a loop iterating over this
		object's cursor, so we create a new connection here 
		for this call by instantiating a ManagerObj
		
		We remember the values for this role as this method
		may be called many times in succession."""
		
		if roleid in self._role_areas_cache:
			return self._role_areas_cache[roleid]
		
		areas = None
		if self.Check_Secured_Areas:
			mgr = ManagerObj()
			sql = """SELECT * FROM AreaRoleRights 
								WHERE ARR_RoleID = %s"""
			areas = []
			for r in mgr.sqlexecute( sql, roleid ).sqlresults():
				if r['arr_areaid'] is None:
					areas = User.Access_All_Areas
					break
				else:
					areas.append( r['arr_areaid'] )
			mgr.finish()
		self.log( areas, tag=">>>> Role's Areas" )
		
		self._role_areas_cache[roleid] = areas
		return areas
