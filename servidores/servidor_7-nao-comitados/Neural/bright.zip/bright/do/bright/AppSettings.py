# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-17 10:54:45 +0000 (Fri, 17 Nov 2006) $
# Revision       $Revision: 1067 $
# Revised by     $Author: ericclack $

# Major change history:


class AppSettings(object):
	"""Application Settings, or local profile, e.g. database connect settings.
	
	These settings are likely to change between development and live environment.
	Put settings that are unlikely to change (e.g. app messages) into 
	busobj.BusSettings"""
	
	db_host = '127.0.0.1'
	db_name = 'bright'
	db_user = 'root'
	db_password = ''
	db_debug = True
	
	# forbidden in file names and paths
	forbidden_chars = '/\\'
	# These get converted to _
	trans_chars = '.:~@'

	# Where is the root of the site, do include final slash
	site_root = '/Library/WebServer/bright/'
	# And the template files?
	tmpl_root = site_root + 'tmpl/'
	tmpl_precompile = 1
	# Resources, such as CMS docs and images, do include final slash
	# If you share with another site make sure this matches 
	# a symbolic link or Apache alias so that URL /resources works
	resources_root = site_root + 'resources/'
	
	# For secure cookies
	md5_secret = 'a9sk!@s9sa'
	
	# For CMS for example
	website_url = 'http://bright.local/'
	
	# For testing set mail_smtp to None, emails are then written to apache log.
	mail_smtp = None
	#mail_smtp = "mailhost.zen.co.uk"
	#mail_smtp = "smtp.nildram.co.uk"

	# Timeout for sessions not covered by a SecurityPolicy
	global_timeout = 30
	
	def __init__(self): pass
	
