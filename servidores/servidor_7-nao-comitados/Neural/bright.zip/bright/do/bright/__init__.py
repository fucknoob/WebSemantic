# (c) 1999-2006 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# Last modified: $Date: 2006-07-15 23:00:30 +0100 (Sat, 15 Jul 2006) $
# Revision       $Revision: 102 $
# Revised by     $Author: ericclack $

# Major change history:


pass