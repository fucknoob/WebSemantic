# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-10 20:24:40 +0000 (Fri, 10 Nov 2006) $
# Revision       $Revision: 1044 $
# Revised by     $Author: ericclack $

# Major change history:



class SecurityPolicy:
	"""Define a security policy for a set of actions.
	
	This class works hand in hand with the Action class in module Webapp.
	How to use:
	 1. Create an instance of this object, policy
	 2. Call class method Action.add_security_policy(policy)
	 3. Then proceed to use action instances as usual.
	 
	If you try to construct an action object which (by its security
	policy) requires an authorised user, but which doesn't have
	an authorised user, the action will set a redirect to the sign
	on page and ignore further template actions. If you then continue
	to try to retrieve the authorised user by calling action.user()
	a NotAuthorised exception will be thrown. 
	
	See Action class for further info.		
	
	Some features of this object require further programming
	over what's provided by the Action class. E.g. see EccoActions.
	"""
	
	default_timeout = 30 # mins	
	
	
	def __init__(self, module, actions, roles, login_page, 
		failed_login_page=None, post_logout_page=None,
		timeout=None, timeout_expiry_page=None, not_permitted_page=None,
		areas=None):
		
		# The module (mod_python action script) to be secured
		self.module = module
		# The actions (methods) to be secured
		self.secured_actions = actions
		# The roles that are permitted to perform these actions
		if isinstance( roles, int ): self.roles = [ roles ]
		else: self.roles = roles
		# The areas that the user must have access to to perform these actions
		if isinstance( areas, int ): self.areas = [ areas ]
		else: self.areas = areas
		
		# Redirects		
		def _else_login_page(var):
			"Return var or login_page if var is None"
			if var: return var
			else: return self.login_page
		
		self.login_page = login_page
		self.failed_login_page = _else_login_page(failed_login_page)
		self.post_logout_page = _else_login_page(post_logout_page)
		self.timeout_expiry_page = _else_login_page(timeout_expiry_page)
		self.not_permitted_page = _else_login_page(not_permitted_page)
		
		if timeout == None: timeout = SecurityPolicy.default_timeout
		self.timeout = timeout
		
		
		
	def secured_module(self, module):
		"""Does this module have some secured actions?"""
		
		secured = False
		if module == self.module: secured = True		
		return secured



	def secured_action(self, module, action):
		"""Is this action in this module secured?"""
		
		secured = False
		if module == self.module and action in self.secured_actions:
			secured = True
			
		return secured
	
	
	
	
	#-------------------------------------------------------------------
	# STATIC METHODS
	#-------------------------------------------------------------------


	
						
	#-------------------------------------------------------------------
	# HELPERS
	#-------------------------------------------------------------------			
						 	 
	
	
			