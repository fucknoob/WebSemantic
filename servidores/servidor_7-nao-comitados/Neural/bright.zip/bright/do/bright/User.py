# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-21 12:48:46 +0000 (Tue, 21 Nov 2006) $
# Revision       $Revision: 1077 $
# Revised by     $Author: ericclack $

# Major change history:
#	5Jul06	Eric	Added meta1,2,3 attributes


import datetime
from bright.BusinessObj import *



class User(BusinessObj):
	"""A user, who's been signed on.
	
	This object is used by Webapp to record authorised users and is
	pickled to a cookie to maintain user authorisation for actions
	defined by a SecurityPolicy object.
	
	BECAUSE THIS OBJECT IS PICKLED TO A COOKIE IT MUST BE KEPT
	SMALL (LESS THAN 2 Kbytes OF INFO WHEN PICKED, which makes
	allowance for extra cookie info within the standard 4K limit).
	"""
	
	
	Access_All_Areas = -1
	Role_Super = 1
	
	
	def __init__(self, internalid, username, name, email, roleid, 
		org=None, position=None, linkid=None, meta1=None, meta2=None,
		meta3=None, areas=None):
		BusinessObj.__init__(self)
		
		self.internalid = internalid
		self.username = username
		self.name = name
		self.email = email
		self.roleid = roleid
		
		self.org = org
		self.position = position # e.g. Communications Officer
		self.linkid = linkid
		
		# These are general purpose attributes
		self.meta1 = meta1
		self.meta2 = meta2
		self.meta3 = meta3

		# A list of areas to which the user has access, or None which
		# can mean N/A, or Access_All_Areas
		self.areas = areas

		self.timeout = None # minutes
		self.last_action = None # datetime

	
	def is_super(self):
		return (self.roleid == User.Role_Super)
	
	
	def reset_timeout(self):
		"""The user has just performed an action, so reset timer"""
		self.last_action = datetime.datetime.now()
		
		
	def has_timed_out(self):
		"""Has this user timed out, due to lack of activity?"""
		# If no timer set, timeout now
		if not self.last_action: return True
		
		# Otherwise, add on minutes passed in
		expires_at = self.last_action + datetime.timedelta(minutes=self.timeout)
		return (expires_at <= datetime.datetime.now())
		
						
	#-------------------------------------------------------------------
	# HELPERS
	#-------------------------------------------------------------------			
						 	 
	