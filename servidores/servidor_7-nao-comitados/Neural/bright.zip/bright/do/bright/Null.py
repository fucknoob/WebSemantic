# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006-11-17 10:54:45 +0000 (Fri, 17 Nov 2006) $
# Revision       $Revision: 1067 $
# Revised by     $Author: ericclack $

# Major change history:


"""This is a sample implementation of the 'Null Object' design pattern.

Roughly, the goal with Null objects is to provide an 'intelligent'
replacement for the often used primitive data type None in Python or
Null (or Null pointers) in other languages. These are used for many
purposes including the important case where one member of some group 
of otherwise similar elements is special for whatever reason. Most 
often this results in conditional statements to distinguish between
ordinary elements and the primitive Null value.

Among the advantages of using Null objects are the following:

  - Superfluous conditional statements can be avoided 
	by providing a first class object alternative for 
	the primitive value None.

  - Code readability is improved.

  - Null objects can act as a placeholder for objects 
	with behaviour that is not yet implemented.

  - Null objects can be replaced for any other class.

  - Null objects are very predictable at what they do.

To cope with the disadvantage of creating large numbers of passive 
objects that do nothing but occupy memory space Null objects are 
often combined with the Singleton pattern.

For more information use any internet search engine and look for 
combinations of these words: Null, object, design and pattern.

Dinu C. Gherman,
August 2001
"""

class Null(object):
	"""A class for implementing Null objects.

	This class ignores all parameters passed when constructing or 
	calling instances and traps all attribute and method requests. 
	Instances of it always (and reliably) do 'nothing'.

	The code might benefit from implementing some further special 
	Python methods depending on the context in which its instances 
	are used. Especially when comparing and coercing Null objects
	the respective methods' implementation will depend very much
	on the environment and, hence, these special methods are not
	provided here.
	"""

	# object constructing
	
	def __init__(self, *args, **kwargs):
		"Ignore parameters."
		return None

	# object calling

	def __call__(self, *args, **kwargs):
		"Ignore method calls."
		return self

	# attribute handling

	def __getattr__(self, mname):
		"""Ignore attribute requests.
		
		But raise exception for Cheetah so that null objects
		work in templates."""

		if mname == 'has_key':
			raise AttributeError
		else:
			return self

	def __setattr__(self, name, value):
		"Ignore attribute setting."
		return self

	def __delattr__(self, name):
		"Ignore deleting attributes."
		return self


	# iterations
	
	def __iter__(self):
		return self
		
	def next(self):
		raise StopIteration


	# misc.

	def __repr__(self):
		"Return a string representation."
		return "<Null>"

	def __str__(self):
		"Convert to a string and return it."
		return ""
		
	def __nonzero__(self):
		"Return false for Cheetah"
		return False
		