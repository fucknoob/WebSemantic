# (c) 1999-2007 Bright Interactive Limited. All rights reserved.
# http://www.bright-interactive.com | info@bright-interactive.com
# Tel: 0870 240 6520

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# Read the license here: http://www.gnu.org/licenses/gpl.txt

# Last modified: $Date: 2006/11/09 16:30:10 $
# Revision       $Revision: 1.1 $
# Revised by     $Author: eric $

# Major change history:



import re
import smtplib
import email
from email.MIMEText import MIMEText
from Cheetah.Template import Template

from bright.BusinessObj import *
from bright.AppSettings import *



class Emailer(BusinessObj):
	"""Sends plain and templated emails (using Cheetah).
	
	Some example uses:
	
		message = "A sale of the following..."
		self.send( mail_from, mail_to, "A sale", message )
		
		self.send_with_template( "contact.txt", dict )
		
		self.prepare_template( "order.txt" )
		self.fill_template_hash( { "customer":"...", "order":"..." } )
		self.send_with_prepared_template()
	"""
	
	
	def __init__(self):		
		BusinessObj.__init__(self)
		
		# Templating stuff for emails
		self._namespace = []
		self._tmpl_dir = AppSettings.tmpl_root + "email"
		self._tmpl_file = None
		self._tmpl_class = None
	
		
	def finish(self): 
		# Nothing to do, but perhaps in future this is 
		# where we dispatch messages?
		pass		


	def send(self, from_addr, to_addr, subject, message, addheaders=True, cc=None, bcc=None):
		"""Send an email and if addheaders is true add the From/To/Subject headers
		
		to_addr, cc and bcc are python lists of recipients."""
		
		if addheaders:
			# Plain text, so add on subject, to, from and cc, but not bcc
			message = "From: %s\nTo: %s\nSubject: %s\nCc: %s\n\n%s" % (from_addr, 
				Emailer._to_string(to_addr), subject, 
				Emailer._to_string(cc), message)

		# Make sure to_addr is a list
		if not isinstance(to_addr,list):
			to_addr = [to_addr]
			
		# If we've cc or bcc recipients, add them to the to_addr list
		if cc: to_addr += cc
		if bcc: to_addr += bcc

		# Now send the message if we have an smtp server, 
		# otherwise simply log message
		if AppSettings.mail_smtp:
			server = smtplib.SMTP( AppSettings.mail_smtp )
			error_codes = server.sendmail( from_addr, to_addr, message )
			server.quit()
			if error_codes: self.log( error_codes )
		else:
			self.log( message )
		self.log( "Message sent to: %s" % to_addr, tag="Notify" )
		
		
	def send_with_template(self, template, dict):
		"""Send a templated email given the supplied template file and dict.
		
		The template must contain To, Subject and From fields.
		It may also contain Cc, Bcc fields."""
		
		# Prepare the template and dict
		self.prepare_template( template )
		self.fill_template_dict( dict )
		
		self.send_with_prepared_template()
		
		
	def send_with_prepared_template(self):
		"""Send an email assuming self's template has already been prepared."""
	
		# Process the prepared template
		message = self.process_template()

		# Retrieve To, From, CC, BCC and Subject:
		from_addr = self._header_from_message( 'From', message, split=True )
		to_addr = self._header_from_message( 'To', message, split=True )
		cc_addr = self._header_from_message( 'Cc', message, split=True )
		bcc_addr = self._header_from_message( 'Bcc', message, split=True )
		subject = self._header_from_message( 'Subject', message )
		
		# Send the email
		self.send(from_addr, to_addr, subject, message, False, cc=cc_addr, bcc=bcc_addr)			
	

	# ---------------------------------------------------------------
	# Template helper methods 
	# ---------------------------------------------------------------	




	def prepare_template(self, tmpl):
		"""Store template definition (either filename or Template class) for later output."""
		
		# Reset vals in case this function is called multiple
		# times with different templates (often the case in error handlers)
		self._tmpl_class = self._tmpl_file = None
		
		if not(isinstance(tmpl, basestring)) and issubclass(tmpl, Template):
			self._tmpl_class = tmpl
		else:
			# Otherwise assume it's a string
			self._tmpl_file = tmpl

	
	def fill_template(self, name, value):
		"""Make $name available in template with supplied value"""
		self._namespace.append( { name:value } )
		
		
	def fill_template_dict(self, dict):
		"""Make all keys in dict available in template with their values"""
		for k in dict.keys():
			if dict[k] is not None:
				self._namespace.append( { k:dict[k] } )
		
	
	def process_template(self):
		"""Record either a template class passed in (previously
		# compiled with cheetah compile) or a filename of a template"""
		if self._tmpl_class:
			t = self._tmpl_class( searchList = self._namespace )
			# Set this for includes
			t._fileDirName = self._tmpl_dir
		else:
			t = Template(file = self._tmpl_dir + "/" + self._tmpl_file, searchList = self._namespace )
			
		# This call might use a manager, so call it before
		# finishing with them
		html = str(t)

		return html	
		
		
	#-------------------------------------------------------------------
	# PUBLIC HELPERS
	#-------------------------------------------------------------------


	@staticmethod
	def is_emailaddr(email):
		"""Is e a valid email address (in terms of its format)."""
		
		r = re.compile( r"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z0-9_\-\.]+)$" )
		if r.match(email): return True
		else: return False		


	#-------------------------------------------------------------------
	# PRIVATE HELPERS
	#-------------------------------------------------------------------
		
	
	@staticmethod
	def _header_from_message(header, message, split=False):
		"""Retrieve headers from the message and split them into list if required"""

		# Only consider headers present in the top bit of the 
		# email, before the first blank line -- as per email spec
		topmessage = message.split("\n\n")[0]

		# Now find header
		r = re.compile( "^%s: (.*)$" % header, re.MULTILINE | re.IGNORECASE )
		val = None
		match = r.search(topmessage)
		if match:
			val = match.group(1)		
			
		if split and val:
			val = val.split(',')

		return val
		
		
	@staticmethod
	def _to_string(list_of_recipients):
		"""Convert list of recipients to a comma separated string"""
		if isinstance(list_of_recipients,str):
			# It's already a string
			s = list_of_recipients
		else:
			# It should be a list
			try:
				s = ",".join(list_of_recipients)
			except TypeError:
				s = ""
		return s		
		


class HTMLEmailer(Emailer):
	"""Like Emailer but send templated HTML emails.
	
	E.g.:
		message = "<html><body><hr>This is some <b>html</b><hr></body></html>"
		self.send( mail_from, mail_to_scd, "Test HTML Message", message )
	"""
	
	def __init__(self):
		Emailer.__init__(self)
	
	
	def send(self, from_addr, to_addr, subject, message, cc=None, bcc=None):
		"""Send an HTML email using MIME encoding.
		
		to_addr, cc and bcc are python lists of recipients."""
		
		mime = MIMEText( message, 'html' )
		mime['From'] = from_addr
		mime['To'] = Emailer._to_string(to_addr)
		mime['Subject'] = subject
		
		if cc: mime['Cc'] = Emailer._to_string(cc)
		if bcc: mime['Bcc'] = Emailer._to_string(bcc)
			
		Emailer.send(self, from_addr, to_addr, subject, mime.as_string(), False, cc, bcc)
