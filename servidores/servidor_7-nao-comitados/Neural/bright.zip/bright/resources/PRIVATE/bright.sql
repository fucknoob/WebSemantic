# CocoaMySQL dump
# Version 0.7b4
# http://cocoamysql.sourceforge.net
#
# Host: 127.0.0.1 (MySQL 4.1.18)
# Database: bright
# Generation Time: 2007-01-16 21:23:22 +0000
# ************************************************************

# Dump of table List
# ------------------------------------------------------------

CREATE TABLE `List` (
  `ListID` int(11) NOT NULL auto_increment,
  `Name` varchar(255) default NULL,
  `Code` varchar(255) default NULL,
  `Description` text,
  PRIMARY KEY  (`ListID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `List` (`ListID`,`Name`,`Code`,`Description`) VALUES ('1','News','news','Welcome to the news area of the website');
INSERT INTO `List` (`ListID`,`Name`,`Code`,`Description`) VALUES ('2','FAQs','faq','Read frequently asked questions.');


