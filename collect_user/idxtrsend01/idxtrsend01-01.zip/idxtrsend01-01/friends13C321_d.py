
import os
import sys
import time
import simplejson
import urllib
import urllib2
import umisc
import gc
import thread
import time
import logging
import bson


logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger('GET-FACEBOOK->COLLECT')
 
 
import threading

lock = threading.Lock()

def insere_usr(user_name,idc,u_name,fcb2): 
   # por enquanto nao tiver coletando usuario, return
   ky=str(idc)
   print 'insert.usr(',ky,')'
   fcb2.insert({'_id':ky,'user_name':  user_name ,'id':ky , 'u_name':u_name,'indexed':'N','important':'S'})
   print 'insert OKK...',ky

def post_cmd(arr,usr,u_nm,idk,fcb2):   
  try:
   #print 'insert rows.id(',idk,'):',len(arr)
   for its in arr:
     [a,u_id,u_name]=its
     insere_usr('',u_id,u_name,fcb2)
     #print 'insert-->rows.id:',u_id
     pass
  except: 
   log.exception("error insert rowds.id("+str(idk)+")")      
  
def post_termo(it,termo,purpose,user,prep,web):
 with lock:
  print 'post text:',len(it)
  try:
     for its in it:
         [ from_msg,msg_id,msg_story,msg_caption,msg_description,msg_picture,msg_link,msg_name,msg_icon,msg_type,msg_likes,msg_message ]=its 
         
         if msg_message== None: msg_message=''
         if msg_caption== None: msg_caption=''
         if msg_description== None: msg_description=''
         if msg_name== None: msg_name=''
         if msg_story== None: msg_story=''
         if msg_picture== None: msg_picture=''
         if msg_link== None: msg_link=''
         if msg_icon== None: msg_icon=''
         if msg_type== None: msg_type=''
         if len(from_msg) == 0: from_msg.append(['0',msg_name])
         
         
         try:  
          msg_caption=msg_caption.encode('latin-1','ignore')   
         except : pass

         try:  
          m1=msg_name.encode('latin-1','ignore')
         except Exception,err : print 'Erro msg_caption(1):',err,msg_caption,msg_name

         try:  
          msg_caption=msg_caption+' '+m1
         except Exception,err : print 'Erro msg_caption(2):',err,msg_caption,msg_name
         

         try:  
          msg_link=msg_link.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_message=msg_message.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_description=msg_description.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_icon=msg_icon.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_picture=msg_picture.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_story=msg_story.encode('latin-1','ignore')   
         except : pass
         try:  
          msg_type=msg_type.encode('latin-1','ignore')   
         except : pass
         try:  
          from_msg[1]=from_msg[1].encode('latin-1','ignore')
         except : pass
         try:  
          msg_id=msg_id.encode('latin-1','ignore')
         except : pass
         
          
         
         msg_link=msg_link.replace('\n','')
         msg_icon=msg_icon.replace('\n','')
         msg_picture=msg_picture.replace('\n','')
         msg_story=msg_story.replace('\n','')
         msg_caption=msg_caption.replace('\n','')
         msg_message=msg_message.replace('\n','')
         msg_description=msg_description.replace('\n','')
          
         msg_link=msg_link.replace('\\n','')
         msg_message=msg_message.replace('\\n','')
         msg_description=msg_description.replace('\\n','')
         msg_icon=msg_icon.replace('\\n','')
         msg_picture=msg_picture.replace('\\n','')
         msg_story=msg_story.replace('\\n','')
         msg_caption=msg_caption.replace('\\n','')
         
         all_msg=msg_message +' '+msg_description 
         
         if msg_type == u'status':
          all_msg=msg_story 
          msg_link='{owner}'      
         
         
         if umisc.trim(all_msg) <> '' or umisc.trim(msg_caption) <> '': 
          if umisc.trim(msg_link) == '' : msg_link='-'
          if umisc.trim(all_msg) == '': all_msg='-'
          if umisc.trim(termo) == '' : termo='-'
          if umisc.trim(user) == '' : user='-'
          if umisc.trim(purpose) == '' :purpose ='-'
          if umisc.trim(msg_icon) == '' :msg_icon ='-'
          if umisc.trim(msg_picture) == '' : msg_picture='-'
          if umisc.trim(from_msg[0]) == '' : from_msg[0]='0'
          if umisc.trim(from_msg[1]) == '' :from_msg[1] ='-'
          if umisc.trim(msg_story) == '' :msg_story ='-'
          if umisc.trim(msg_type) == '' : msg_type='-'
          from_msg=(from_msg)
          if umisc.trim(msg_id) == '' : msg_id='-'
          # 
          PG=all_msg
          fnd=True
          fnd2=False
          if True:
            if 'are now friends' in PG :
             fnd2=True
            elif 'is now friends with' in PG :
             fnd2=True
            elif PG[:7] =='http://'  :
             fnd2=True
            elif 'likes' in PG : 
             fnd2=True
            elif '{like}' in PG:           
             fnd2=True              
          try:  
           if fnd and not fnd2:          
            pass
            web.insert(msg_id,{'url':msg_link,'pg':bson.Binary(all_msg) ,'termo':bson.Binary(termo),'usr':bson.Binary(user),'purpose':bson.Binary(purpose),'processed':'N','url_icon':msg_icon,\
                                  'url_picture':msg_picture,'id_usr':str(from_msg),'name_usr':'','story':bson.Binary(msg_story),'title':bson.Binary(msg_caption),\
                                  'doc_id':msg_id,'tp':msg_type,'tps':'F','indexed':'N','id':msg_id})
          except Exception,err:
           log.exception("Error post facebook item:")          
         else:
          pass 
  except:
   log.exception("")
  print 'post.term OK.' 
 
 
 
 
tokens=[]

il=0
while il < 210:
 tokens.append(None)
 il+=1


 
 
tokens[199]='342297925890698|e8Z0sfEk4C1QsRYddnhYGiTMBBE'
tokens[198]='639867876042862|sIOhiJ4LQa5wBF_Nsk3uv7-90q0' 
tokens[197]='140059119498348|26E21CWhzZYZf83C-qxV-Oi3tZY'
tokens[196]='439176372831254|wEa_7AybPE9LA8Ny1S9bUznW2OQ'
tokens[195]='524349027607967|1x1ocnJ1NYsLx3-2O9qfg8pK5nA'
tokens[194]='423769027708087|-eq_2e7SHcdJV44fLSGVcpRx5Io'
tokens[193]='341124109325115|D9dUjIgIYWWlcSngpj3Ty6DB7Yo'
tokens[192]='487822007944103|c6v_4IHRtx8ZWFrZ2XtDfEGKwgw'
tokens[191]='510890778954407|Mq-lVV-PgqELOnr80pGBxuDTdP4'
tokens[190]='488406387879768|MNihz851BPbaCZlUE9vF30cqDYE'
tokens[189]='379675202140272|Es8zkMcTDAMz4d2McnMOkQ0kbBQ'
tokens[188]='222192207925341|B-Ze8SZUiGnhMnghCiAATZwb6w8'
tokens[187]='162320250591840|6jndicQDj8YgHfga3NJxfqv2KEE'
tokens[186]='562214360463921|GKdbZIoE3q9T8fi4LhAcqo4DvM0'
tokens[185]='521515587887188|v88hLEgtdHTCFfIWLdTcPgN7O7Q'
tokens[184]='143154009185550|SlwteC33mTO27I202kWb6Ip2_1g'
tokens[183]='128846493962473|mKUfk9dB5nT0bueKlMdWap-RlBk'  
tokens[182]='436475979759857|y5uRJqX23I4fK0cChHXysiJyVHk'
tokens[181]='152163471610315|jnUlhQDe-BvredXvNLlncxg6ySg'
tokens[180]='430622980354937|WdkF7tShNE89noQUsTOJUhWa93g'
tokens[179]='132853053558777|UEbBzbJTt4dg8AbPkzPV4XrJ0qw'
tokens[178]='471850762868813|0FHgE5PI3lDrWLZKDEI3jcXu9eE'
tokens[177]='546489328717886|vT6oTkyJ2MI4_wUPAceTsfL-WzY'
tokens[176]='172583849555937|vAxNQPm-WqT4i8tJh8dfR7vjDa4'  
tokens[175]='221797974633657|Sf2e-5RkC2N9Put5mmsBBqEE-3Q' 
tokens[174]='449426581794285|2aLlKzKu9RBYkyltdwO3PMKSbx0' 
tokens[173]='100192456837036|LwGzWpDGbfci0G2Eq1BfJXDhf38'
tokens[172]='137090663127475|NSY7njMNLux97Fso9rTtuBWh98A'
tokens[171]='513270582057701|Eg3W6VwNWekY8JUTmXR0LowMRAw'
tokens[170]='188986434558866|0cX6fmPBqwcTm5meVQOLoao4YN8' 
tokens[169]='226497987491232|5QT9Ol0rOL7x0vG-VGMhwtwBMhc'
tokens[168]='497647106959190|MXwBwCHvik7GE443LxdfIO__pFU' 
tokens[167]='348124345296976|8wLxoUjp4XZKq-ujCLfmIrkYnxU'
tokens[166]='517260394990855|MtKYfICOnm1qlkiZXc18OWsslBA'
tokens[165]='430015123749909|phpz6JPQNgx-xtunkGsYtEw9bCc'
tokens[164]='563464453678457|8J-uUesGtHv61uyO9YVp8TlhGhw'
tokens[163]='529400947082887|a47I9Ox2pb1gp3yimc5We9yb-OU'
tokens[162]='574348549245088|ckCzVR62UsBFMa2aGkMxP1AyN-k'
tokens[161]='477037512352239|2ko1Uep--NfoAweRgKLAN98rhpY'
tokens[160]='483252228402257|c-jz36w8rzUHNynFRCXiigtDxfI' 
tokens[159]='613263715357067|whR-T9hvC0pScgvF65ab_xt4AfQ'
tokens[158]='107852799384937|T2dBPx3kk9dK57ouaKGS3vNU0D8' 
tokens[157]='347211275389960|NXLD3FRy8tf2YultTHPoBPOeFl0'
tokens[156]='577927638897780|fYvhaKypiSbXxam0y0CXx6c_UEc'
tokens[155]='536558349717506|xU2rZ_EzqSE53xq5dvGpL88u7V4'
tokens[154]='152412961583468|kKMxouvq8qkQoDdw7NjNRP7vejo'
tokens[153]='422989071120755|FJm5PDaa8pEP0yUN7WE7caHWw-o'
tokens[152]='421686171255791|cRfU4HDywrtKKMLKHFgV1EQzbdk'
tokens[151]='144859379009432|fbaedrRChCEiBWExmr23vhRnnLo'
tokens[150]='558766304143182|Tu24ejaTo7jsmpqVcwX0nmouI1U'
tokens[149]='368418229932570|1Ek-ggqo_HIwWPcseFfwcLI0ukk'
tokens[148]='440275279381398|-RHdmpja84V2kaCvpUJ2-Luhn_8'
tokens[147]='479203372147163|lxKHOmZTUNxTUBK8mSVOYmGBMeE'
tokens[146]='532386043448780|uAdTF4klJOOzRnTQMPB8S1fEp0s'
tokens[145]='540596275971818|WGOG4-77i74NWOQb-OUTeG0Nn00'
tokens[144]='212689678876756|GmBL2JYpgnOqAzgKJm-ecwdzNRQ'
tokens[143]='241451205992188|MHE80Q5ApflqsRZwdtrKBd_NN8o'
tokens[142]='292027807593736|g-6pg7OWcur42CMFyD5Hyb6-ZHQ'
tokens[141]='538633296167886|Bdw7ymFW2NHOtv_huREajRjQbPU'
tokens[130]='433881890025808|D0kdJd0o03BHJCCDyaB4O_3U80s'
tokens[139]='486585281405838|FFHzDMWT3IZqN2hgrYtTJCGbblU'
tokens[138]='335042546597100|nTnzeNDaUxNpdQjj_lpWZu1hSOw'
tokens[137]='527929807251380|W7y9NLHiE4bzrORyURp9SFdgImA'
tokens[136]='159391570881637|yzA1-eLm7kbL4wi4bowfvx_z7tk'
tokens[135]='343587332418941|EfnHPh32gf1rHXq5up6Oswtenk0'
tokens[134]='121461448035692|4z3bZJHFimUjOImCo5WNU8rSpOc'
tokens[133]='541445592554265|i-n8DHQIHj6M_R2qYw2znst77gY'
tokens[132]='445431948858991|9emS_RNnTT-7AtKjb5Jp-gQZhOI'
tokens[131]='412021278891698|TEx-GbUJtfC_kZXjko_60dFax2w'
tokens[130]='344164322356768|D6GiezoepN2lfX3vsKbrk9bIQ9g'
tokens[129]='431046983630836|KudqynGWcVEYE2uzvcfHxflhwvI'
tokens[128]='488000317928047|j-Bi7DvIxP0MK4vkC-QDStH94sg'
tokens[127]='140340406129503|H-KmDtTR0gGy_vzPSHttzxgRS6k'
tokens[126]='338624246246319|-Dz-etLgJsEHiUihA4f9tAJBcQk'
tokens[125]='430951943650688|ZhUkw8DNJxhPnHVvGZ_GUiWVMDk'
tokens[124]='333625310075436|mFLhsN4JXIRHdhNrs2WBjl8UBc8'
tokens[123]='333862646714535|oGpuv_fwa74hQAOWEW8cJeTqZww'
tokens[122]='123277254516880|0UtUhYxFzfOhqaUQ6ryoG0NiGeA'
tokens[121]='326490144129558|FAGR3TiWLerriH_XUIHkQMJcpo8'
tokens[120]='426035490806918|vJftgwMhcHpY3wFVjjNcVZvwM7k' 
tokens[119]='386459591441254|A5t_SUmvz8icX_KZZ4VmxAulrBU'      
tokens[118]='133520460140565|sQ86q65pby1ek6CCngarywU51nA'      
tokens[117]='130476403781113|JnKbEIwbD6c7YL0lXMAaRZSbmdk'      
tokens[116]='210200879116690|l8ZTuij9batvtjScFqr9s_WQIxE'      
tokens[115]='130873000405995|5N0XoPtYqnfP0LBj8g-oeIO90MI'    
tokens[114]='511192748901567|PO75Ulo6CECzYc9qG-HjSsK6J-U'      
tokens[113]='551320231564366|0st6A6ZIHSTnytvrwPozGoFf260'      
tokens[112]='323755687729999|p-YAUWo1Sc-2hRYPqi9mHUu6_k0'      
tokens[111]='301848573269756|fDJa-7eeto12npt2JpdDO4X7P6E'      
tokens[110]='565607786802000|-zWYLRUaAsvZuJBtZ8NwddhYup0'    
tokens[109]='345103052259008|gOLxPskuR2cKdGQAhn8lAaqC_FY'
tokens[108]='131243283749454|Ec95HnVp2G3MsxS9Vxp4aFC3dxg'
tokens[107]='641678495861899|tVzvW6h_OGsv5zX3IW9YL0SLyVo'
tokens[106]='647494131945601|R358Q2vpfsGr6hHhn76obU_tU2Y'
tokens[105]='279430828867133|oDYyF_Mo1lzLdR4wkhQHRoDLe3U'
tokens[104]='393667194083385|jS0DawABfDcic2rDSf5tCm0JAD8'
tokens[103]='327846987347852|EILH1uqgE2skFkQHYQOwgQ2XScc'
tokens[102]='347330482060628|61gTwHmHvUJ0raTwbWfrCf35X6U'
tokens[101]='539213326141543|9_02MsvIg2VXUtGfbBWSvGwj1LE'
tokens[100]='216003411880661|SSuEhz3n1pghSo152qbuzAraUrk'
tokens[99]='569727923080108|pFurU3p3YxkiMYB2vv90Uez05Uo'
tokens[98]='179841615515745|tP9T9tWw7JGdVOt8hMR9AhEL1D0'
tokens[97]='178022575699658|GCj7-Uxp5VL2ELykIrgDuvdC_Cs'
tokens[96]='508271765916863|JbgG4Wxi8CkmY-5vXsHaqLMBCg0'
tokens[95]='1394468857431996|X8uOc3FexKWmmZwJ21iepPdsQOI'
tokens[94]='390388174399801|Mtj6LQyyOtFW7U0Ih7lTfFrx6To'
tokens[93]='570001326377116|29guAlSCZA-aSQPD9eaHlRHgdGM'
tokens[92]='265375526937034|TofJqEfs-x96CY1A58mrrIiPBH8'
tokens[91]='387815217991691|cSmMxFfFhG9WyUwVXgI_bbPnN2I'
tokens[90]='391457380966648|gwkTBxlQ17dakHpvOkD_dc9W-HI'
tokens[89]='520715657992835|uZeYTz30uletMtIoa4hkVY4UvrE'
tokens[88]='546685038723804|86VMor5GeV53Ur4jFIV2PtGn0tY'
tokens[87]='546743168717768|OCEmvRJuvGDAHxz2JuMIlYbqCBQ'
tokens[86]='1375914089293082|R6PBRC_CCO0rViNBZNk9h9VAbVY'
tokens[85]='396678627107482|BFUhos11PMhxEjkTET58vp2ftMc'
tokens[84]='385995944835008|6VS3ufVBjoawWU6-l5Fz0wO5OBk'
tokens[83]='481756265233246|jF5-r6ttwIa-tY_AFH_7viIgfdw'
tokens[82]='142732162590059|sBncCla-3bLw_E0sLsE455BzReA'
tokens[81]='166467866866980|4WIcW5UI4wwRIX_4q85jVnbGSEA'
tokens[80]='393472300757327|Vnv2enqegTEpUVqgQ5p6jMmIN_c'
tokens[79]='204842699671392|H9WpWy_3t8PaBQAFW_h3i5fUJ8o'
tokens[78]='527726090626569|hpoddCH_4x-nczj8DLMqdUBZ-x0'
tokens[77]='413927238722217|t92ZSTVZo6CZ31beBjPAjZ-TEYc'
tokens[76]='600877503298124|Pk-Q05dYVvm9M-tMQ3MzVdNKZDw'
tokens[75]='213638252122362|b8DVejVtB_VjaTVgouaqKRIPYB8'
tokens[74]='370792973043556|z76iwwwi7rBm5UHvrls8tKO5yt8'
tokens[73]='218320418292407|3zEh01OTSJiSFS9W-gwJCuoqZrU'
tokens[72]='403005196484258|KacYileL1k4o1V4BKM2yIn1cweY'
tokens[71]='475852239172112|v9TRuwi-Oci6q-9SRJzIL5nh7BI'
tokens[70]='584172644938942|9fYWKUiOATYbSgXRrg1sDtELA5I'
tokens[69]='209019092584111|jMNzuDe_uQ31qnEadp2M1ROb7hs'
tokens[68]='384630618309963|iaMsNri8BQk7NgWDBCwIKfqFkj8'
tokens[67]='156661331185886|Vznn362DfH3DKo9p0qRR_qnt9xI'
tokens[66]='154029674787944|cQAToATRoCopkkb-AC9F_-NjzoM'
tokens[65]='613911118628285|IsekmHWjAvI09_wHfevztVyDseI'
tokens[64]='402823799834538|5EcYDjZ2ogAzrFgTj-Jm7405pUM'
tokens[63]='599121286794665|oKJg3B_bYDEdUyZfkh5BiWURL9s'
tokens[62]='384640041636811|QDCJOiur7cYKJpWPWJ_ZbxTi6KI'
tokens[61]='389543747823228|zgMwD1NjjhKS4LF1wwOhEAQT8BA'
tokens[60]='649908355038731|wp3o2W_Q2JsAzs9Rc4q3y9nPfkc'
tokens[59]='133774226829354|zdV4coGa20M7GLT5eauD21eUtPI'
tokens[58]='196088110549634|IfEYkq4ZeiTRh0CKtiyG2Il1VNs'
tokens[57]='165147340331728|lwDBlTzhvkjZQFJXKhp7FQzLL4U'
tokens[56]='381958248576434|_cd5a7MLt6cH-CJNvyuxrV9cjSY'
tokens[55]='192384317590753|D7v7hFUynZTpdh6n5hjwP3A9rqo'
tokens[54]='373271919462020|tMoxXGkAIHh6Fk0bGgRVP5umA08'
tokens[53]='501896623214129|FVerhptT8frnqPPmBkc4LPXn0d8'
tokens[52]='564424453601376|qHFI1Tm47yclgNsHjxhXrj9pmtk'
tokens[51]='125196891024082|LtU4wTrJW5IW22BZM5JGLXLcRcM'
tokens[50]='149734811882572|7OXnImAZaJDbI8wfFQy9930UNoA'
tokens[49]='205356046285814|Ly4JK2LIY1wCOXwJbfB9xRKtj1Q'
tokens[48]='612695998748630|wzsHtC6bXL02xBrw35wssdB_a6s'
tokens[47]='149280115265059|x1XetJBr9QkuxVM11hUaJloVyZk'
tokens[46]='170655133115403|7vJOyb1C8uL7DpxCnab6hz7O-tc'
tokens[45]='543964589001012|zOLnc674mnHJfPboxUGzWiTKPfI'
tokens[44]='173404559505038|ZPh5kt9qWIvyehjmiwW6ZEX4YQI'
tokens[43]='158634844321979|lj8YfHHVvJmaTMdiNYVMPnp0gFo'
tokens[42]='144570762406205|3wHqI9gFHs-SapjXxM0ZABXt89A'
tokens[41]='469390806484059|KB9n3f9TrXzm7bqTOKzIhxBMmAo'
tokens[40]='457336477698240|pLX7qDhpLmoy9Zx-uy6mkNhQ2iA'
tokens[39]='185311031635471|WB25Cf5nxC5h0pZmPhv2dRk2VMY'
tokens[38]='190620021101658|AM4GLjq4KXdKtXHfI0kSoSkXBlI'
tokens[37]='149408125252703|36I4nanV-ZnVEnoY3URBL020M8A'
tokens[36]='463002087124262|4ceEwtPeyo0KC-S5Nf46N7cBAa8'
tokens[35]='208213732666153|MUGW0tib-i_DsJeeISIx68YX33s'
tokens[34]='162728833912548|WXrWs28eDdVxLj1f6ClzrxMcxxo'
tokens[33]='138158206388351|OC-KgdupbU8bAgXE-5NAZSgteTk'
tokens[32]='486123398129312|rmXCnwL8n4MmahN9amdRcLguTxE'
tokens[31]='326911347442151|CxMIgj_tLxM1wlbrKFbWUZL-rOM'
tokens[30]='319637051504173|58t1IrALhINu7YB9mi2v4z-yX50'
tokens[29]='133680100173534|rO7wvQBgCr8Qzr9LVDm7i_t7Fww'
tokens[28]='209550019198326|iLMhNUpon4Da61OdR-1j84VbG2g'
tokens[27]='140735916126448|RVaBbgMhHC0Ux9XmBXAbQi0ja3U'
tokens[26]='465411503549971|LLnf6YpxSBqvqcXis0ztYsugZf0'
tokens[25]='176344439207853|zyVJAsuq9Xiu5-13ptH-7xQEiDs'
tokens[24]='550735158322453|uws11xgdtoW-kZ6nvRBaVuqbo2Q'
tokens[23]='133659040174104|0BIl1nPTOM8XmOReySm2rnDU66U'
tokens[22]='600954409935551|MpKMAUdVd_srCV4lK52_n3fxmyU'
tokens[21]='127660920777783|dUB3vCjU08qluQbUgT7dYDibjOg'
tokens[20]='537545592958401|SEeC0ttTyPRwayLOms7M-C_Vwz8'
tokens[19]='192658637560095|OhDr3y3aLEMhmq85cTaLDGEfT5g'
tokens[18]='210050789146093|ocLscHcEqgFZkeV5WuB0Cu1G5GA'
tokens[17]='477815885633879|WB-9G0vCrzlQV-BfQWaH2Z7dXU8'
tokens[16]='151181198408378|CyEUqOLiwHblsS5O1KovU0nx2FI'
tokens[15]='286051718205704|cYv8b2Jb1wG4ArDg9NzDu4zY8dk'
tokens[14]='150523185140448|DRTzJPvWeLGMXBtdt1RKFuHWt5M'
tokens[13]='494488497294137|g1HDKO8LMEEE5Dfr0bRvgTmijbs'
tokens[12]='339845696146609|cPGX0j_z9dDgOQLp1_uvYGvLM7s'
tokens[11]='646296188731879|cjsuMM_HirJQU5hfpdd0MMOD0Iw'
tokens[10]='408127505971791|yXBu8pq7I6aYN-kpZxAEbCiO2Ts'
tokens[9]='576339045749589|D-5uOEz124ZeIE12o0UVKpnzaTg'
tokens[8]='443676062394493|5G0tOgmNPWZ_TOoH3BbWtxTV6z0'
tokens[7]='536959253032755|xKFJxCc65ESp2IVn_490ZyJVBhg'
tokens[6]='371722006283005|6mER01EN2gFTPyMcHt8jeK_LA8g'
tokens[5]='673883639294796|V2rgJGNU8n20NH0kjNWj383UEKM'
tokens[4]='525866630795956|LIeInu63PniPVzWr6PNLb68fsXk'
tokens[3]='331611370302765|XSJEOnuFJurJxKsQSNVkdV1xCAc'
tokens[2]='352496838210650|M-pOSPqBxXT2YkHQF4BHWBwyN_8'
tokens[1]='189164627916277|0urSzN5s4UseE-C61MbIvJOWC_E'
tokens[0]='177591989085589|73y-tpL8RH9YEKDTXSwgfmWF2Y8'





  
 
 
def get_feeds(id,cs,c_url,to_ins,pg_id,user,processo,fcb,fcb2,web):
 ac=[]
 idk=id
 kuser=user
 errorcks=False
 try:
    args = {}
    
    
    
    #args['access_token'] =  tokens[processo-1]
    args['access_token'],args['limit'] =  tokens[processo-1],'100'
    url='https://graph.facebook.com/'+id+'/feed?' + urllib.urlencode(args)
    #url='https://173.252.73.52/'+id+'/feed?' + urllib.urlencode(args)
    
    
    if c_url != '':
     url=c_url
    
    print 'get page(process):',processo
    retry=False
    try:
     file = urllib2.urlopen(url, timeout=5)
    except:
       retry=True
    if retry:
     args['access_token']  =  tokens[processo-1] 
     url='https://graph.facebook.com/'+id+'/feed?' + urllib.urlencode(args)
     file = urllib2.urlopen(url, timeout=5)
       
    print 'pg.returned...',processo
    
    
    result = simplejson.load(file)    
        
    r2=result['data']
    msg_i=1
    object_id=''
    link=''
    icon=''
    type=''
    message=''
    created_time=''
    story=''
    for ch in r2:     
     try:
      id=ch[u'id']
     except: pass 
     try:
      _from=ch[u'from']
     except: pass 
     try:
      likes=ch[u'likes']
     except: 
      likes=None     
     try:
      message=ch[u'message']
     except: pass 
     try:
      link=ch[u'link']
     except: pass 
     try:
      icon=ch[u'icon']
     except: pass 
     try:
      type=ch[u'type']
     except: pass 
     try:
      status_type=ch[u'status_type']
     except: pass 
     try:
      object_id=ch[u'object_id']
     except: pass 
     try:
      created_time=ch[u'created_time']
     except: pass 
     try:
      updated_time=ch[u'updated_time']
     except: pass 
     try:
      shares=ch[u'shares']
     except: pass 
     try:
      comments=ch[u'comments']
     except: 
      comments=None
      
     try:
      story=ch[u'story']
     except: 
      story=''
       
     if id != None:  
      object_id=id
     from_msg=''
     msg_story=''
     msg_caption=''
     msg_likes='0'
     msg_name=''
     msg_picture=''
     msg_description=''
     from_id=''
     if _from != None:
      msg_name=_from[u'name']
      from_id=_from[u'id']
      
     ac.append( [ from_id,object_id,story,msg_caption,msg_description,msg_picture,link,msg_name,icon,type,msg_likes,message ] )
     
     message=''
     
     if comments != None:
       try:
        its=comments[u'data']
        for it in its:
         created_time=it[u'created_time']
         message=''
         message=it[u'message']
         _from=it[u'from']
         u_name=_from[u'name']
         u_id=_from[u'id']
         #print u_name,u_id
         ac.append( [ u_id,object_id,'','','','',link,u_name,icon,type,'0',message ] )
         #=================
         to_ins.append(['',u_id.encode('latin-1'),u_name.encode('latin-1')])
       except Exception,e: 
          pass       
       
     if likes != None:
       try:
        its=likes[u'data']
        for it in its:
         u_name=it[u'name']
         u_id=it[u'id']
         message='{like}'
         #print u_name,u_id
         ac.append( [ u_id,object_id,'','','','',link,u_name,icon,type,'0',message ] )
         #=================
         to_ins.append(['',u_id.encode('latin-1'),u_name.encode('latin-1')])          
       except Exception,e: 
          pass       
     
     msg_i+=1
     
    post_cmd(to_ins,pg_id,user,idk,fcb2)     
    post_termo(ac,'user','user','igor.moraes','user',web )
    closeu(pg_id,fcb)
 except Exception,err2:
  closeu2(pg_id,fcb)
  print 'Error(2.1):',err2
  log.exception("")
  errorcks=True
 

def closeu(ids,fcb):
        key=str(ids)
        gt2=fcb.find({'id':key})
        for gt in gt2: 
         gt[u'indexed'] = 'S'
         fcb.update({'_id':gt['_id']},gt)
         print 'Close usr(1):',ids        

def closeu2(ids,fcb):# in errors
        key=str(ids)
        gt2=fcb.find({'id':key})
        for gt in gt2: 
         gt[u'indexed'] = 'G'
         fcb.update({'_id':gt['_id']},gt)
         print 'Close usr(1):',ids        
 

def parse(s):
 rt=[]
 tmp=''
 for s1 in s:
  if s1 == ',':
     rt.append(tmp)
     tmp=''
  else:
     tmp+=s1
 return rt      

def entry(params,fcb2,fcb,web): 
 #====================
 sents=parse(params) 
 get_feeds(sents[0],0,'',[],int(sents[1]),sents[2],int(sents[3]),fcb,fcb2,web )
 
 
 
 
 