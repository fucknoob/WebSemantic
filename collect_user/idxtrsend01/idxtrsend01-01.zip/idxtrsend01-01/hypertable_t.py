import sys
sys.path.append("./py")
sys.path.append("./py/gen-py")

from hypertable.thriftclient import *
from hyperthrift.gen.ttypes import *

print 'connecting...'


client = ThriftClient("91.205.172.85", 38080)

print 'connected!'

namespace = client.namespace_open("MINDNET")

print 'openned:MINDNET'

'''

client.hql_query(namespace, 'insert into fcb_users values("r1","id","1")')
client.hql_query(namespace, 'insert into fcb_users values("r1","indexed","N")')
client.hql_query(namespace, 'insert into fcb_users values("r1","user_name","a")')
client.hql_query(namespace, 'insert into fcb_users values("r1","u_name","a")')
#
client.hql_query(namespace, 'insert into fcb_users values("r2","id","2")')
client.hql_query(namespace, 'insert into fcb_users values("r2","indexed","S")')
client.hql_query(namespace, 'insert into fcb_users values("r2","user_name","b")')
client.hql_query(namespace, 'insert into fcb_users values("r2","u_name","b")')
#
client.hql_query(namespace, 'insert into fcb_users values("r3","id","3")')
client.hql_query(namespace, 'insert into fcb_users values("r3","indexed","N")')
client.hql_query(namespace, 'insert into fcb_users values("r3","user_name","C")')
client.hql_query(namespace, 'insert into fcb_users values("r3","u_name","c")')
#
'''

print 'get.indexes...'

res = client.hql_query(namespace, "select indexed from fcb_users where indexed=\"N\"")

keys=[]
for r in res.cells:
 
 if  r.key.row not in keys:
   keys.append(r.key.row)
   
rows={}  
   
print 'get.rows...'   
   
for k in keys:
   colunas=client.hql_query(namespace,'SELECT * FROM fcb_users WHERE ROW = "'+k+'"') 
   rw={}
   antr=None
   rc=False
   for cl in colunas.cells:
     rc=False
     val=cl.value
     coluna=cl.key.column_family
     linha=cl.key.row
     if antr != None:
      if linha != antr:
       rows[linha]=rw
       rw={}
       rc=True
     rw[coluna]=val
     antr=linha
   if rc==False  :
       rows[linha]=rw
   #=======================================   

   
print 'print results...'   
aresult=[]   
for ky in rows:
  #print '->:',ky
  #print 'det:',rows[ky]
  aresult.append(rows[ky])
   
for cols in aresult:
  print '->:',cols   
'''


print 'result:' 
'''

client.namespace_close(namespace)


