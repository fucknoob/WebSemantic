
import sys
sys.path.append('./pymongo')
import pymongo


MONGO_URL='mongodb://mind1:acc159753@ds031978.mongolab.com:31978/mind1'
print 'to connect...'
conn = pymongo.Connection(MONGO_URL)
database=conn['mind1']
print 'connected.'