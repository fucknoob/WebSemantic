#!/usr/bin/env python

#
#	Client that doesn't use the Name Server. Uses PYROLOC:// URI.
#

import sys
import Pyro.core
import threading
import time 
import logging

logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger('DYNAMIC-CODE-ENGINE')



import thread
 
lock = threading.Lock()
 
sys.path.append('./pymongo')  

import pymongo

#cassandra
import pycassa
from pycassa.pool import ConnectionPool
from pycassa import index
from pycassa.columnfamily import ColumnFamily

#hypertable
#import hyper_tb

 
import socket   
import simplejson as json
 
pool2 = ConnectionPool('MINDNET', ['79.143.185.3:9160'],timeout=10000)
web1=pycassa.ColumnFamily(pool2, 'web_cache3')
 
 
def get_feeds(u,itsc,itsc2,th,arrc1,uip,u2,indc ):
 if True:
     processo=17
     if indc > 5 and indc <=10:
      processo=18
     elif indc > 10 and indc <=15:    
      processo=19
     elif indc > 15 and indc <=20:    
      processo=20
     #=================
     cmd=''+str(u)+','+str(uip)+','+str(u2)+','+str(processo)+','
     return cmd

     
#=============================================================================
MONGO_URL='mongodb://mdnet1:acc159753@91.205.172.85:27017/mdnet'
connM = pymongo.Connection(MONGO_URL) 
dbM=connM.mdnet
fcb=dbM['fcb_users']
#web1=dbM['web_cache']
#=============================================================================
mongo_arr=[web1]
mongo_arr2=[fcb]


     
cache_pg=[]  
atu_index=0
pools=[]
mongos=[]
 
 
s = socket.socket()          
host = '91.205.172.85'
port = 1022     

def get_by_zeus():
 while True:
  try:
    s = socket.socket() 
    s.connect((host, port))
    msg='G'
    s.send(msg)
    msg = s.recv(2045)
    arrpg=json.loads(msg)
    s.close()
    #===================================================================   
  except Exception,e:
    print 'error:',e
    time.sleep(30)
    continue
  return arrpg
   
    
def pre_get_pages(first=False): 
  global cache_pg
  global atu_index
  cache_pg=[]
  atu_index=0
  fnd=False
  curs=get_by_zeus()
  for cr in curs:
   fnd=True 
   cache_pg.append(cr)
  
   
     
     
def get_pages(i,a):
 arrpg=[]
 global atu_index
 global cache_pg
 if atu_index >= len(cache_pg):
   pre_get_pages()
   
 print 'Getting pages...'
 while atu_index < len(cache_pg):
  cr=cache_pg[atu_index]
  arrpg.append([cr[0],cr[0]])
  atu_index+=1
  if len(arrpg) >= 15: break
 #============================== 
 return arrpg
  
import time
from threading import Thread

class thread_cntl:
 def __init__(self):
  self.finished=False

import friends13C321_d

class connectionwb:
 def __init__(self,_webs):
   self.webs=_webs
   self.atu=0
   self.lock=threading.Lock()
 def reset(self):
   self.atu=0
 def test_get(self,val):  
    for aw in self.webs:
     r=aw.find({'id':val['id']}) 
     for a in r:
      return True
    return False      
 def insert(self,val):
  print 'insert:',val['id']
  with self.lock: 
   try:
      #if not self.test_get(val):
      r=self.webs[self.atu].insert(val,w=1)     
   except pymongo.errors.OperationFailure,err :   #  
      try:
       log.exception("")   
      except: pass 
      errr=str(err)
      print 'get.exception-------------[',errr,']'      
      if 'quota exceeded' in errr:
       print 'Quota FULL************'
       print 'change table.....from:',self.atu,' to:',self.atu+1
       self.atu+=1
       if self.atu >= len(self.webs):
         self.atu=0
         return self.webs[self.atu]
       return self.webs[self.atu].insert(val,w=1)
      else: return None 
   except Exception :     
      global connM
      global dbM
      global fcb
      global MONGO_URL
      import time
      time.sleep(4)    
      connM = pymongo.Connection(MONGO_URL) 
      dbM=connM.mdnet
      fcb=dbM['fcb_users']
      try:
          #if not self.test_get(val):
          self.webs[self.atu]=fcb
          r=self.webs[self.atu].insert(val,w=1)     
      except :   #  
       log.exception("Error scann...") 
       return None 


class connectionwb2:
 def __init__(self,_webs):
   self.webs=_webs
   self.atu=0
   self.lock=threading.Lock()
 def reset(self):
   self.atu=0
 def test_get(self,val):  
    for aw in self.webs:
     r=aw.find({'id':val['id']}) 
     for a in r:
      return True
    return False      
 def insert(self,ky,val):
  print 'insert:',val['id']
  with self.lock: 
   try:
      #if not self.test_get(val):
      r=self.webs[self.atu].insert(ky,val)     
   except Exception,err :   #  
      try:
       log.exception("")   
      except: pass 
   except Exception :     
    log.exception("Error scann...") 
    return None 
    
def run_cmd(params,thr1,_pool,_mongo):
 [cass_pool,cass_fcb]=_pool
 [_mongo_database,mongo_fcb,mongo_web]=_mongo 
 try:
  print 'pg.run:',params,cass_fcb,mongo_fcb,mongo_web
  friends13C321_d.entry(params,cass_fcb,mongo_fcb,mongo_web)
 except: pass
 thr1.finished=True
  
#====================  
connw=connectionwb2(mongo_arr)
connw2=connectionwb(mongo_arr2)
for i in range(0,15):
 fcb2_1=connw2
 pool2_1=None
 #cassandra
 #pool2_1 = ConnectionPool('MINDNET', ['91.205.172.85:9160'],timeout=10000000)
 #fcb2_1 = pycassa.ColumnFamily(pool2_1, 'fcb_users3')
 #hyperable
 #fcb2_1=hyper_tb.hypconnection()
 #fcb2_1.open()
 #=================================
 pools.append([pool2_1,fcb2_1]) 
 #======================
 web=connw
 #=========
 mongos.append([connM,fcb,web]) 
  
def process_p(arrpg1,dm):
 print 'pages ok. init process ... len:',len(arrpg1),',len2:',len(pools)
 thst=[]
 indc=0
 for pg in arrpg1:
   [u,uip]=pg
   thst.append(thread_cntl())
   params=get_feeds(u,0,'',None,[],uip,u,indc)
   #==========================
   t = Thread(target=run_cmd, args=(params,thst[len(thst)-1],pools[indc],mongos[indc]))
   t.start()
   indc+=1

 while True:
  fndac=False
  for t in thst:
   if not t.finished: fndac=True
  time.sleep(.5)
  if not fndac: break  
 
 
while True:  
 #
 try:
  a1=get_pages(1,1)
  #
  process_p(a1,0 )
  #
 except: 
  log.exception("")
 time.sleep(.5)

 
 
  
 


  