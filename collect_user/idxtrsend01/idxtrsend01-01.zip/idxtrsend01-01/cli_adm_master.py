# master call of clients

import sys
import os
import thread
import time




def execute_one(a,b):  
 while True:
  cmd='python cli_adm.py'
  os.system(cmd)
 
def execute_two(a,b):
 while True:
  cmd='python cli_adm2.py'
  os.system(cmd) 
 
 
def execute_three(a,b):
 while True:
  cmd='python cli_adm3.py'
  os.system(cmd)  
 
def execute_four(a,b):
 while True:
  cmd='python cli_adm4.py'
  os.system(cmd)  
 
def execute_five(a,b):
 while True:
  cmd='python cli_adm5.py'
  os.system(cmd)  
 

print 'start index daemon....'
 
thread.start_new_thread(execute_one,(0,0) )
thread.start_new_thread(execute_two,(0,0) )
thread.start_new_thread(execute_three,(0,0) )
thread.start_new_thread(execute_four,(0,0) )
thread.start_new_thread(execute_five,(0,0) )


while True:
  time.sleep(10) 